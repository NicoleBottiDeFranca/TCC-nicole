<?php


  if (!empty($_GET['id'])) {

    include_once ("conexao2.php");
   
    $id= $_GET['id'];
    $sqlSelect = "SELECT * FROM tb_clientes WHERE cod_cli=$id";
    $result = $conexao-> query($sqlSelect);
    
    if($result-> num_rows > 0)
    {
      while($user_data = mysqli_fetch_assoc($result))
      {
    $nome   = $user_data['nome_cli'];
    $data_nasc = $user_data['data_nasc_cli'];
    $cpf  = $user_data['cpf_cli'];
    $email  = $user_data['email_cli'];
    $bairro  = $user_data['bairro_cli'];
    $rua  = $user_data['rua_cli'];
    $numero  = $user_data['num_cli'];
    $complemento  = $user_data['complemento_cli'];
    $cidade  = $user_data['cod_cid'];
    $telefone  = $user_data['tel_cli'];
    $cep  = $user_data['cep_cli'];

    }
    
  }
    else
    {
      header('location:pesquisa_cli.php');
    }

    
  }

    
?>
      

<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="css/style_clicad.css">
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-compatible" content="IE=edge">
  <link rel="shortcut icon" href="img/logo.png">
  <meta name="viewport" content="width=device-width, initial-sacle=1.0">
  <script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/jquery.mask.js"></script>
    <script type="text/javascript" src="js/mask.js"></script>
  <title>editar cliente</title>
</head>
<body>
  <div class="header" id="header">
    <div class="logo_header">
      <img src="img/logo.png" alt="sales_portas">
    </div>

    <div class="nagivation_header">
      <ul>
        <li><a href="visu_agend.php" >agendamentos</a>
          <ul>
            <li><a href="pesquisa_agend.php">visualizar</a></li>
            <li><a href="cad_agend.php">cadastrar</a></li>
          </ul>
        </li>
      <li><a href="visu_agend.html" >Serviços</a>
          <ul>
            <li><a href="pesquisaserv.html">visualizar</a></li>
           
          </ul>
          
        <li><a href="visu_cli.php" class="active">clientes</a>
          <ul>
            <li><a href="pesquisa_cli.php">visualizar</a></li>
            <li><a href="cadastrocli.php" class="active">cadastrar</a></li>
          </ul>
        </li>
       
      </ul>
      <ul> 
      <button class="btn_sair"><img src="img/poder.png" alt=""> </button>
    </div>
  </div>

  <form action="saveEditcli.php" method="post">
    <div class="main-cadastro">
      <div class="Cadastro">
        <div class="card-cadastro">
          <h1>Alteração Do Cliente</h1><br><br><br><br>
          
          <div class="textfield">
            <label for="nome">Nome:</label>
            <input type="text" name="nome_cli" id="nome_cli" size="40" placeholder="nome completo" value="<?php echo $nome ?>">
          </div>

          <div class="textfield">
            <label for="data_nasc">Data de Nascimento:</label>
            <input type="date" name="data_nasc_cli" id="data_nasc_cli" placeholder="dd/mm/aaaa" value="<?php echo $data_nasc ?>">
          </div>

          <div class="textfield">
            <label for="cpf">CPF:</label>
            <input type="text" class="cpf" name="cpf_cli" id="cpf_cli" size="10" placeholder="somente números" value="<?php echo $cpf ?>">
          </div>
          <div class="textfield">
            <label for="email">Email:</label>
            <input type="email" size="80" name="email_cli" id="email_cli" placeholder="Email válido" value="<?php echo $email ?>">
          </div>

          <div class="textfield">
          <label for="bairro">Bairro</label>
          <input type="text" name="bairro_cli" id="bairro_cli" value="<?php echo $bairro ?>">
      </div>
      <div class="textfield">

        <label for="rua">Rua </label>
        <input type="text" name="rua_cli" id="rua_cli" value="<?php echo $rua ?>">
        </div>

    <div class="textfield">
      <label for="numero">Número</label>
      <input type="text" name="num_cli" id="num_cli" value="<?php echo $numero ?>" >
     </div>

        <div class="textfield">
            <label for="complemento">complemento:</label>
            <input type="text" name="complemento_cli" id="complemento_cli" size="10" value="<?php echo $complemento?>">
          </div>

          <div class="textfield">
            <label for="cidade">Cidade</label>
            <input type="text" name="cod_cid" id="cod_cid"  value="1" value="<?php echo $cidade ?>">
          </div>

           <div class="textfield">
            <label for="telefone">Telefone:</label>
            <input type="text" class="sp_celphones"  name="tel_cli" id="telefone_cli" size="10" placeholder="somente números" value="<?php echo $telefone ?>">
          </div>
          
           
          <div class="textfield">
            <label for="cep">CEP</label>
            <input type="text" class="cep" name="cep_cli" id="cep_cli"  placeholder="somente numeros" value="<?php echo $cep ?>">
        </div>
        <input type="hidden" name="cod_cli" value="<?php  echo $id?>">
        
    
    <button class="btn-1" name="update">Alterar</button>
          <button class="btn-2" name="btncancelar">Cancelar</button>
        </div>
      </div>
    </div>
  </form>
  
</body>
</html>
</body>
</html>
