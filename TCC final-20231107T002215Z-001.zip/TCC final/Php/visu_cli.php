<?php


session_start();


if (!isset($_SESSION['usuario'])) {
    
    header('Location: pagina_login.php');
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="css/style_visucli_func.css">
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-compatible" content="IE=edge">
  <link rel="shortcut icon" href="img/logo.png">
  <meta name="viewport" content="width=device-width, initial-sacle=1.0">
  <title>clientes</title>
</head>
<body>
  <div class="header" id="header">
    <div class="logo_header">
      <img src="img/logo.png" alt="sales_portas">
    </div>

    <div class="nagivation_header">
      <ul>
        <li><a href="visu_agend.php" >agendamentos</a>
          <ul>
            <li><a href="pesquisa_agend.php">visualizar</a></li>
            <li><a href="cad_agend.php">cadastrar</a></li>
          </ul>
        </li>
       <li><a href="visu_serv.php" >Serviços</a>
          <ul>
            <li><a href="pesquisaserv.php">visualizar</a></li>
            
          </ul>
          
        <li><a href="visu_cli.php" class="active">clientes</a>
          <ul>
            <li><a href="pesquisa_cli.php" >visualizar</a></li>
            <li><a href="cadastrocli.php" >cadastrar</a></li>
          </ul>
        </li>
        
      </ul>
      <div class="btn_sair">
  <p>Olá, <?php echo $_SESSION['usuario']; ?>!</p>
   <a href="logout.php">Sair</a>
</div>
    </div>
  </div>
  <h1>Clientes:</h1>
  <div class="imagem">
    <img src="img/img_cli.svg" class="img_c" alt=""><br>
  </div>
  <div class="imagema">
    <button class="button"> <a href="pesquisa_cli.php">pesquisar</a></button>
     <button class="button"> <a href="cadastrocli.php">cadastrar</a></button>
   </div>
 
 
    
</body></html>