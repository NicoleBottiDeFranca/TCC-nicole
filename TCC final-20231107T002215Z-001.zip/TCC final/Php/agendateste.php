<?php
session_start();

include_once "conexao.php";
$pdo = conectar();

$message = ''; // Variável para exibir mensagens

$sql = "SELECT a.*, f.nome_func, s.nome_serv, c.nome_cli 
        FROM tb_agendamentos a
        INNER JOIN tb_funcionarios f ON a.cod_func_fk = f.cod_func
        INNER JOIN tb_servicos s ON a.cod_serv_fk = s.cod_serv
        INNER JOIN tb_clientes c ON a.cod_cli_fk = c.cod_cli";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$agendamentos = $stmt->fetchAll(PDO::FETCH_ASSOC);

$sqlFuncionarios = "SELECT * FROM tb_funcionarios";
$stmtFuncionarios = $pdo->prepare($sqlFuncionarios);
$stmtFuncionarios->execute();
$dadosFuncionarios = $stmtFuncionarios->fetchAll(PDO::FETCH_ASSOC);

$sqlServicos = "SELECT * FROM tb_servicos";
$stmtServicos = $pdo->prepare($sqlServicos);
$stmtServicos->execute();
$dadosServicos = $stmtServicos->fetchAll(PDO::FETCH_ASSOC);

$sqlClientes = "SELECT * FROM tb_clientes";
$stmtClientes = $pdo->prepare($sqlClientes);
$stmtClientes->execute();
$dadosClientes = $stmtClientes->fetchAll(PDO::FETCH_ASSOC);

function cadastrarAgend(&$message) {
    global $pdo;
    
    if (isset($_POST['btnsalvar'])) {
        $cod_func_fk = $_POST['cod_func_fk'];
        $cod_serv_fk = $_POST['cod_serv_fk'];
        $cod_cli_fk = $_POST['cod_cli_fk'];
        $data_agend = $_POST['data_agend'];
        $hora_agend = $_POST['hora_agend'];
        $evento_ocupado = $_POST['evento_ocupado'];
        if (!empty($evento_ocupado)) {
            $message = 'Já existe um agendamento nesse dia e horário.';
        } else {

        // Verificar se já existe um agendamento no mesmo dia e horário
        $stmtVerificar = $pdo->prepare("SELECT * FROM tb_agendamentos WHERE data_agend = :data_agend AND hora_agend = :hora_agend");
        $stmtVerificar->bindParam(':data_agend', $data_agend);
        $stmtVerificar->bindParam(':hora_agend', $hora_agend);
        $stmtVerificar->execute();
        
        if ($stmtVerificar->rowCount() > 0) {
            $message = 'Já existe um agendamento nesse dia e horário.';
        } else {
            try {
                $stmt = $pdo->prepare("INSERT INTO tb_agendamentos (cod_func_fk, cod_serv_fk, cod_cli_fk, data_agend, hora_agend) VALUES (:cod_func_fk, :cod_serv_fk, :cod_cli_fk, :data_agend, :hora_agend)");

                $stmt->bindParam(':cod_func_fk', $cod_func_fk);
                $stmt->bindParam(':cod_serv_fk', $cod_serv_fk);
                $stmt->bindParam(':cod_cli_fk', $cod_cli_fk);
                $stmt->bindParam(':data_agend', $data_agend);
                $stmt->bindParam(':hora_agend', $hora_agend);

                if ($stmt->execute()) {
                    $message = 'Cadastro realizado com sucesso!';
                    header("Location: sucesso_adm.php");
                    exit;
                } else {
                    $message = 'Algum dos dados informados está inválido.';
                }
            } catch (Exception $e) {
                $message = 'Erro ao cadastrar: ' . $e->getMessage();
            }
        }
    }
}
    return $message;
}

cadastrarAgend($message);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Agenda Semanal</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .agenda {
            width: 80%;
            margin: 0 auto;
        }
        .dia-semana {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #ccc;
            padding: 10px 0;
            font-weight: bold;
        }
        .dia-semana div {
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .dia-semana div:hover {
            background-color: #eee;
        }
        .hora {
            font-weight: bold;
        }
        .horario {
            border: 1px solid #ccc;
            padding: 10px;
            cursor: pointer;
        }
        .evento {
            background-color: #f0f0f0;
            border: 1px solid #ccc;
            padding: 5px;
            margin: 5px 0;
        }
        #formulario {
            display: none;
            position: absolute;
            background: white;
            padding: 20px;
            border: 1px solid #ccc;
            z-index: 2;
        }
        .data-semana {
            text-align: center;
            font-size: 18px;
        }
    </style>
</head>
<body>
    <div class="agenda">
        <h1>Agenda Semanal</h1>
        <div class="data-semana">
            <p id="nome-dia-semana"></p>
            <p id="data-semana"></p>
        </div>
        <div class="dia-semana" id="dias-semana">
            <button onclick="anteriorDia()">Anterior</button>
            <div></div>
            <button onclick="proximoDia()">Próximo</button>
        </div>
        <div class="horario">
            <div class="hora">09:00</div>
            <div class="evento" onclick="mostrarFormulario('09:00')">Clique para agendar</div>
            <?php mostrarAgendamentos("09:00"); ?>
        </div>
        <div class="horario">
            <div class="hora">10:00</div>
            <div class="evento" onclick="mostrarFormulario('10:00')">Clique para agendar</div>
            <?php mostrarAgendamentos("10:00"); ?>
        </div>
        <div class="horario">
            <div class="hora">11:00</div>
            <div class="evento" onclick="mostrarFormulario('11:00')">Clique para agendar</div>
            <?php mostrarAgendamentos("11:00"); ?>
        </div>
        <div class="horario">
            <div class="hora">13:00</div>
            <div class="evento" onclick="mostrarFormulario('13:00')">Clique para agendar</div>
            <?php mostrarAgendamentos("13:00"); ?>
        </div>
        <div class="horario">
            <div class="hora">14:00</div>
            <div class="evento" onclick="mostrarFormulario('14:00')">Clique para agendar</div>
            <?php mostrarAgendamentos("14:00"); ?>
        </div>
        <div class="horario">
            <div class="hora">15:00</div>
            <div class="evento" onclick="mostrarFormulario('15:00')">Clique para agendar</div>
            <?php mostrarAgendamentos("15:00"); ?>
        </div>
    </div>

    <?php
function mostrarAgendamentos($hora) {
    global $agendamentos;
    $agendamentosNoHorario = array_filter($agendamentos, function ($agendamento) use ($hora) {
        return $agendamento['hora_agend'] === $hora;
    });

    if (!empty($agendamentosNoHorario)) {
        foreach ($agendamentosNoHorario as $agendamento) {
            echo '<div class="agendamento-existente">';
            echo 'Nome do cliente: ' . $agendamento['nome_cli'] . '<br>';
            echo 'Funcionário: ' . $agendamento['nome_func'] . '<br>';
            echo 'Serviço: ' . $agendamento['nome_serv'] . '<br>';
            echo '</div>';
        }
    }
}
?>

    <div id="formulario">
        <h2>Agendar Evento</h2>
        <form action="" method="post">
            <div class="main-cadastro">
                <div class="card-cadastro">
                    <div class="textfield">
                        <label for="funcionario">Funcionário:</label>
                        <select id="cod_func_fk" name="cod_func_fk">
                            <?php foreach ($dadosFuncionarios as $funcionario) {
                                echo "<option value='{$funcionario['cod_func']}'>{$funcionario['nome_func']}</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="textfield">
                        <label for="servicos">Serviço:</label>
                        <select id="cod_serv_fk" name="cod_serv_fk">
                            <?php foreach ($dadosServicos as $servico) {
                                echo "<option value='{$servico['cod_serv']}'>{$servico['nome_serv']}</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="textfield">
                        <label for="clientes">Cliente:</label>
                        <select id="cod_cli_fk" name="cod_cli_fk">
                            <?php foreach ($dadosClientes as $cliente) {
                                echo "<option value='{$cliente['cod_cli']}'>{$cliente['nome_cli']}</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="textfield">
                        <label for="data_agend">Data de agendamento:</label>
                        <input type="date" name="data_agend" id="data_agend">
                    </div>
                    <div class="textfield">
                        <label for="hora_agend">Horário de agendamento:</label>
                        <input type="time" name="hora_agend" id="hora_agend">
                    </div>
                    <input type="hidden" name="evento_ocupado" id="evento_ocupado" value="">

                    <button class="btn-1" name="btnsalvar">Cadastrar</button>
                    <button class="btn-2" name="btncancelar">Cancelar</button>
                </div>
            </div>
        </form>
        <?php if (!empty($message)) : ?>
        <div><?php echo $message; ?></div>
    <?php endif; ?>
    </div>
</body>
</html>

<script>
    let diaSelecionado = 1; // Começa com a segunda-feira (1)
    let horaSelecionada = "";

    const eventos = {
        1: {},
        2: {},
        3: {},
        4: {},
        5: {},
        6: {},
        0: {}
    };

    const nomesDiasSemana = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];

    function mostrarDia(dia) {
        diaSelecionado = dia;
        limparAgenda();
        listarEventos();
        atualizarDataSemana();
    }

    function mostrarFormulario(hora, eventoId) {
    const formulario = document.getElementById("formulario");
    formulario.style.display = "block";
    formulario.style.top = (event.clientY + 10) + "px";
    formulario.style.left = (event.clientX + 10) + "px";

    horaSelecionada = hora;

    document.getElementById("hora_agend").value = horaSelecionada;

    // Definir o ID do evento no campo de evento_ocupado
    document.getElementById("evento_ocupado").value = eventoId;
}


    function agendarEvento() {
        const cod_func_fk = document.getElementById("cod_func_fk").value;
        const cod_serv_fk = document.getElementById("cod_serv_fk").value;
        const cod_cli_fk = document.getElementById("cod_cli_fk").value;
        const data_agend = document.getElementById("data_agend").value;
        const hora_agend = horaSelecionada;

        // Use esses valores para inserir no banco de dados
        // ...

        listarEventos();
        document.getElementById("formulario").style.display = "none";
    }

    function limparAgenda() {
        const horarios = document.querySelectorAll(".horario .evento");
        horarios.forEach((horario) => {
            horario.innerHTML = "Clique para agendar";
        });
    }

    function listarEventos() {
        limparAgenda();
        const horarios = document.querySelectorAll(".horario");
        horarios.forEach((horario) => {
            const hora = horario.querySelector(".hora").textContent;
            const evento = eventos[diaSelecionado][hora];
            if (evento) {
                horario.querySelector(".evento").innerHTML = evento;
            }
        });
    }

    function atualizarDataSemana() {
        const hoje = new Date();
        const dataAtual = new Date(hoje.getFullYear(), hoje.getMonth(), hoje.getDate() + (diaSelecionado - hoje.getDay()));
        document.getElementById("nome-dia-semana").innerText = nomesDiasSemana[diaSelecionado];
        document.getElementById("data-semana").innerText = dataAtual.toLocaleDateString();
    }

    function calcularDataAgendamento() {
        const hoje = new Date();
        const dataAtual = new Date(hoje.getFullYear(), hoje.getMonth(), hoje.getDate() + (diaSelecionado - hoje.getDay()));
        return dataAtual.toISOString().slice(0, 10); // Formato "YYYY-MM-DD"
    }

    function anteriorDia() {
        if (diaSelecionado === 0) {
            mostrarDia(6); // Domingo
        } else {
            mostrarDia(diaSelecionado - 1);
        }
    }

    function proximoDia() {
        if (diaSelecionado === 6) {
            mostrarDia(0); // Segunda-feira
        } else {
            mostrarDia(diaSelecionado + 1);
        }
    }

    mostrarDia(new Date().getDay()); // Exibir o dia atual
</script>