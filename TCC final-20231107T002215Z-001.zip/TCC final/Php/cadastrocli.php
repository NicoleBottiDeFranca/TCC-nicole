<?php



session_start();


if (!isset($_SESSION['usuario'])) {
    
    header('Location: pagina_login.php');
    exit;
}

include_once "conexaosales.php";

function cadastrarCliente()
{ $pdo = conectar();
  $message = '';

  if (isset($_POST['btnsalvar'])) {
    $nome   = $_POST["nome_cli"];
    $data_nasc  =$_POST["data_nasc_cli"];
    $cpf  = $_POST["cpf_cli"];
    $email  = $_POST["email_cli"];
    $bairro  = $_POST["bairro_cli"];
    $rua  = $_POST["rua_cli"];
    $numero  = $_POST["num_cli"];
    $complemento  = $_POST["complemento_cli"];
    $cidade  = $_POST["cod_cid"];
    $telefone  = $_POST["tel_cli"];
    $cep  = $_POST["cep_cli"];
    

      try {
          $stmt = $pdo->prepare("INSERT INTO tb_clientes (nome_cli, data_nasc_cli, cpf_cli, email_cli, bairro_cli, rua_cli, num_cli, complemento_cli, cod_cid, tel_cli, cep_cli)  VALUES (:nome_cli, :data_nasc_cli, :cpf_cli, :email_cli, :bairro_cli, :rua_cli, :num_cli, :complemento_cli, :cod_cid, :tel_cli, :cep_cli)");
          $stmt->bindParam(':nome_cli', $nome );
          $stmt->bindParam(':data_nasc_cli', $data_nasc);
          $stmt->bindParam(':cpf_cli', $cpf);
          $stmt->bindParam(':email_cli', $email);
          $stmt->bindParam(':bairro_cli', $bairro);
          $stmt->bindParam(':rua_cli', $rua );
          $stmt->bindParam(':num_cli', $numero);
          $stmt->bindParam(':complemento_cli', $complemento);
          $stmt->bindParam(':cod_cid', $cidade);
          $stmt->bindParam(':tel_cli', $telefone);
          $stmt->bindParam(':cep_cli', $cep);

          if ($stmt->execute()) {
              $message = 'cliente cadastrado com sucesso!';
              header("Location: sucesso.php");
              exit; 
          } else {
              $message = 'Algum dos dados informados está inválido.';
          }
      } catch (Exception $e) {
          $message = 'Erro ao cadastrar: ' . $e->getMessage();
      }
  }

  return $message;
}

$message = cadastrarCliente();
?>

<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="css/style_clicad.css">
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-compatible" content="IE=edge">
  <link rel="shortcut icon" href="img/logo.png">
  <meta name="viewport" content="width=device-width, initial-sacle=1.0">
  <script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/jquery.mask.js"></script>
    <script type="text/javascript" src="js/mask.js"></script>
  <title>cadastro cliente</title>
</head>
<body>
  <div class="header" id="header">
    <div class="logo_header">
      <img src="img/logo.png" alt="sales_portas">
    </div>

    <div class="nagivation_header">
      <ul>
        <li><a href="visu_agend.php" >agendamentos</a>
          <ul>
            <li><a href="pesquisa_agend.php" >visualizar</a></li>
            <li><a href="cad_agend.php">cadastrar</a></li>
          </ul>
        </li>
          <li><a href="visu_serv.php" >Serviços</a>
          <ul>
            <li><a href="pesquisaserv.php">visualizar</a></li>
           
          </ul>
          
        </li>
        <li><a href="visu_cli.php" class="active">clientes</a>
          <ul>
            <li><a href="pesquisa_cli.php">visualizar</a></li>
            <li><a href="cadastrocli.php" class="active">cadastrar</a></li>
          </ul>
        </li>
       
      </ul>
      <ul> 
      <div class="btn_sair">
  <p>Olá, <?php echo $_SESSION['usuario']; ?>!</p>
   <a href="logout.php">Sair</a>
</div>
    </div>
  </div>

  <form method="post">
    <div class="main-cadastro">
      <div class="Cadastro">
        <div class="card-cadastro">
          <h1>Cadastro Do cliente</h1><br><br><br><br>
          
          <div class="textfield">
            <label for="nome">Nome:</label>
            <input type="text" name="nome_cli" id="nome_cli" size="40" placeholder="nome completo">
          </div>

          <div class="textfield">
            <label for="data_nasc">Data de Nascimento:</label>
            <input type="date" name="data_nasc_cli" id="data_nasc_cli" placeholder="dd/mm/aaaa">
          </div>

          <div class="textfield">
            <label for="cpf">CPF:</label>
            <input type="text" class="cpf" name="cpf_cli" id="cpf_cli" size="10" placeholder="somente números">
          </div>
          <div class="textfield">
            <label for="email">Email:</label>
            <input type="email" size="80" name="email_cli" id="email_cli" placeholder="Email válido">
          </div>

          <div class="textfield">
          <label for="bairro">Bairro</label>
          <input type="text" name="bairro_cli" id="bairro_cli">
      </div>
      <div class="textfield">

        <label for="rua">Rua </label>
        <input type="text" name="rua_cli" id="rua_cli" >
        </div>

    <div class="textfield">
      <label for="numero">Número</label>
      <input type="text" name="num_cli" id="num_cli" >
     </div>

        <div class="textfield">
            <label for="complemento">complemento:</label>
            <input type="text" name="complemento_cli" id="complemento_cli" size="10">
          </div>

          <div class="textfield">
            <label for="cidade">Cidade</label>
            <input type="text" name="cod_cid" id="cod_cid"  placeholder="cascavel" value="1">
          </div>
          <div class="textfield">
            <label for="telefone">Telefone:</label>
            <input type="text" class="sp_celphones" name="tel_cli" id="telefone_cli" size="10" placeholder="somente números">
          </div>
          
           
          <div class="textfield">
            <label for="cep">CEP</label>
            <input type="text" class="cep" name="cep_cli" id="cep_cli"  placeholder="somente numeros">
        </div>
        
    
    <button class="btn-1" name="btnsalvar">Cadastrar</button>
          <button class="btn-2" name="btncancelar">Cancelar</button>
        </div>
      </div>
    </div>
  </form>
  <?php if (!empty($message)) : ?>
        <div><?php echo $message; ?></div>
    <?php endif; ?>
</body>
</html>
</body>
</html>
