<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    
  header('Location: pagina_login.php');
  exit;
}

include_once "conexaosales.php";

$pdo = conectar();

$sql = "SELECT * FROM tb_servicos ORDER BY cod_serv DESC";
$result = $pdo->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
<head>
  

  <link rel="stylesheet" href="css/style_pesquisaserv.css">
  
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-sacle=1.0">
  <link rel="shortcut icon" href="img/logo.png">
  <title>pesquisa serviços</title>
</head>
<body>
<div class="header" id="header">
    <div class="logo_header">
      <img src="img/logo.png" alt="sales_portas">
    </div>

    <div class="nagivation_header">
      <ul>
        <li><a href="visu_agend.php" >agendamentos</a>
          <ul>
            <li><a href="pesquisa_agend.php">visualizar</a></li>
            <li><a href="cad_agend.php">cadastrar</a></li>
          </ul>
        </li>
      <li><a href="visu_serv.php" class="active">Serviços</a>
          <ul>
            <li><a href="pesquisaserv.php"class="active">visualizar</a></li>
            
          </ul>
          
        <li><a href="visu_cli.php"  >clientes</a>
          <ul>
            <li><a href="pesquisa_cli.php">visualizar</a></li>
            <li><a href="cadastrocli.php">cadastrar</a></li>
          </ul>
        </li>
        
      </ul>
      <div class="btn_sair">
  <p>Olá, <?php echo $_SESSION['usuario']; ?>!</p>
   <a href="logout.php">Sair</a>
</div>
    </div>
  </div>
  
  <div class="tabela">
    <br>
    <table>
      
        <tr>
          <th scope="col">Código</th>
          <th scope="col">Nome</th>
          <th scope="col">tipo</th>
          <th scope="col">duração</th>
          
        </tr>
      
    
</div>
      <tbody>
        <?php
        while ($user_data = $result->fetch(PDO::FETCH_ASSOC)) {
          echo "<tr>";
          echo "<td>".$user_data['cod_serv']."</td>";
          echo "<td>".$user_data['nome_serv']."</td>";
          echo "<td>".$user_data['tipo_serv']."</td>";
          echo "<td>".$user_data['tempo_duracao']."</td>";
          
          
          
          echo "</tr>";
        }
        ?>
      </tbody>
    </table>
  </div>
 
</body>
</html>