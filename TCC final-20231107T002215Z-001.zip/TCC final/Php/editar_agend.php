<?php



session_start();


if (!isset($_SESSION['usuario'])) {
    
    header('Location: pagina_login.php');
    exit;
}


include_once("conexao2.php");

$dados_funcionarios = array();
$sqlf = "SELECT * FROM tb_funcionarios";
$resultf = $conexao->query($sqlf);
while ($row = mysqli_fetch_assoc($resultf)) {
    $dados_funcionarios[] = $row;
}

$dados_servicos = array();
$sqls = "SELECT * FROM tb_servicos";
$results = $conexao->query($sqls);
while ($row = mysqli_fetch_assoc($results)) {
    $dados_servicos[] = $row;
}

$dados_clientes = array();
$sqlc = "SELECT * FROM tb_clientes";
$resultc = $conexao->query($sqlc);
while ($row = mysqli_fetch_assoc($resultc)) {
    $dados_clientes[] = $row;
}
$cod_func_fk = $cod_serv_fk = "";
if (!empty($_GET['id'])) {
    include_once ("conexao2.php");
    $id = $_GET['id'];
    $sqlSelect = "SELECT * FROM tb_agendamentos WHERE cod_agendamento=$id";
    $resultAgend = $conexao->query($sqlSelect);
    
    if ($resultAgend->num_rows > 0) {
        while ($user_data = mysqli_fetch_assoc($resultAgend)) {
            $cod_func_fk = $user_data['cod_func_fk'];
            $cod_serv_fk = $user_data['cod_serv_fk'];
            $cod_cli_fk = $user_data['cod_cli_fk'];
            $data_agend = $user_data['data_agend'];
            $hora_agend = $user_data['hora_agend'];
        }
    } else {
        header('location:pesquisa_agend.php');
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="css/style_cad_agendfunc.css">
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-sacle=1.0">
  <link rel="shortcut icon" href="img/logo.png">
  <title>cadastro agendamento</title>
</head>
<body>
<div class="header" id="header">
    <div class="logo_header">
      <img src="img/logo.png" alt="sales_portas">
    </div>

    <div class="nagivation_header">
      <ul>
        <li><a href="visu_agend.php"  class="active">agendamentos</a>
          <ul>
            <li><a href="pesquisa_agend.php" >visualizar</a></li>
            <li><a href="cad_agend.php" class="active">cadastrar</a></li>
          </ul>
        </li>
          <li><a href="visu_serv.php" >Serviços</a>
          <ul>
            <li><a href="pesquisaserv.php">visualizar</a></li>
           
          </ul>
          
        </li>
        <li><a href="visu_cli.php">clientes</a>
          <ul>
            <li><a href="pesquisa_cli.php">visualizar</a></li>
            <li><a href="cadastrocli.php" >cadastrar</a></li>
          </ul>
        </li>
       
      </ul>
      <ul> 
      <div class="btn_sair">
  <p>Olá, <?php echo $_SESSION['usuario']; ?>!</p>
   <a href="logout.php">Sair</a>
</div>
    </div>
  </div>

  <form action="saveagend.php" method="post">
    <div class="main-cadastro">
      <div class="Cadastro">
        <div class="card-cadastro">
          <h1> Alteração do Agendamento</h1><br><br><br><br>
          
          
          <div class="textfield">
    <label for="funcionario">Funcionário:</label>
    <select id="cod_func_fk" name="cod_func_fk">
        <?php foreach ($dados_funcionarios as $d) {  
            $selected = ($d['cod_func'] == $cod_func_fk) ? "selected" : "";
            echo "<option value='{$d['cod_func']}' $selected>{$d['nome_func']}</option>";
        } ?>
    </select>
</div> 

<div class="textfield">
    <label for="servicos">Serviço:</label>
    <select id="cod_serv_fk" name="cod_serv_fk">
        <?php foreach ($dados_servicos as $ds) { 
            $selected = ($ds['cod_serv'] == $cod_serv_fk) ? "selected" : "";
            echo "<option value='{$ds['cod_serv']}' $selected>{$ds['nome_serv']}</option>";
        } ?>
    </select>
</div>

           <div class="textfield">
            <label for="clientes">Cliente:</label>
            <select id="cod_cli_fk" name="cod_cli_fk">
    <?php foreach ($dados_clientes as $dc) {  
        echo "<option value='{$dc['cod_cli']}'>{$dc['nome_cli']}</option>";
    } ?>
     </select>
           </div> 

           <div class="textfield">
            <label for="data_agend">Data de agendamento:</label>
            <input type="date" name="data_agend" id="data_agend"  value="<?php echo $data_agend?>">
          </div>
          <div class="textfield">
            <label for="hora_agend">Horario de agendamento:</label>
            <input type="time" name="hora_agend" id="hora_agend" value="<?php echo $hora_agend ?>">
          </div>

         
          <input type="hidden" name="cod_agendamento" value="<?php  echo $id?>">
    <button class="btn-1" name="update">Alterar</button>
          <button class="btn-2" name="btncancelar">Cancelar</button>
        </div>
      </div>
    </div>
  </form>
</body>
</html>