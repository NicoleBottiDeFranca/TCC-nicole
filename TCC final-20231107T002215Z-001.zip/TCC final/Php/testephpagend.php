<?php
session_start();


if (!isset($_SESSION['usuario'])) {
    
    header('Location: ../pagina_login.php');
    exit;
}
include_once "conexao.php";
$pdo = conectar();
$sqlf = "SELECT * FROM tb_funcionarios";
$stmtf = $pdo->prepare($sqlf);
$stmtf->execute();
$dados = $stmtf->fetchAll(PDO::FETCH_ASSOC);

$sqls = "SELECT * FROM tb_servicos";
$stmts = $pdo->prepare($sqls);
$stmts->execute();
$dadosS = $stmts->fetchAll(PDO::FETCH_ASSOC);

$sqlc = "SELECT * FROM tb_clientes";
$stmtc = $pdo->prepare($sqlc);
$stmtc->execute();
$dadosC = $stmtc->fetchAll(PDO::FETCH_ASSOC);

function cadastrarAgend()
{
    $pdo = conectar();
    $message = '';

    if (isset($_POST['btnsalvar'])) {
        $cod_func_fk = $_POST["cod_func_fk"];
        $cod_serv_fk = $_POST["cod_serv_fk"];
        $cod_cli_fk = $_POST["cod_cli_fk"];
        $data_agend = $_POST["data_agend"];
        $hora_agend = $_POST["hora_agend"];
        

        try {
            $stmt = $pdo->prepare("INSERT INTO tb_agendamentos (cod_func_fk, cod_serv_fk, cod_cli_fk, data_agend, hora_agend) VALUES (:cod_func_fk, :cod_serv_fk, :cod_cli_fk, :data_agend, :hora_agend)");

            $stmt->bindParam(':cod_func_fk', $cod_func_fk);
            $stmt->bindParam(':cod_serv_fk', $cod_serv_fk);
            $stmt->bindParam(':cod_cli_fk', $cod_cli_fk);
            $stmt->bindParam(':data_agend', $data_agend );
            $stmt->bindParam(':hora_agend', $hora_agend );

            if ($stmt->execute()) {
                $message = 'cadastro realizado com sucesso!';
                header("Location: sucesso_adm.php");
                exit; 
            } else {
                $message = 'Algum dos dados informados está inválido.';
            }
        } catch (Exception $e) {
            $message = 'Erro ao cadastrar: ' . $e->getMessage();
        }
    }

    return $message;
}

$message = cadastrarAgend();
?>
<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="../css/style_cad_agendadm.css">
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-sacle=1.0">
  <link rel="shortcut icon" href="../img/logo.png">
  <title>cadastro agendamento</title>
</head>
<body>
  <div class="header" id="header">
    <div class="logo_header">
      <img src="../img/logo.png" alt="sales_portas">
    </div>

    <div class="nagivation_header">
      <ul>
        <li><a href="visu_agend.php" class="active" >agendamentos</a>
          <ul>
            <li><a href="pesquisa_agend.php">visualizar</a></li>
            <li><a href="cad_agend.php"class="active" >cadastrar</a></li>
          </ul>
        </li>
          <li><a href="visu_serv.php" >Serviços</a>
          <ul>
            <li><a href="pesquisaserv.php">visualizar</a></li>
            <li><a href="cadastroserv.php">cadastrar</a></li>
            <li><a href="cadastrofuncserv.php" >funcionário</a></li>
            <li><a href="pesquisafuncserv.php">visualizar FS</a></li>
          </ul>
          
        </li>
        <li><a href="visu_cli.php" >clientes</a>
          <ul>
            <li><a href="pesquisa_cli.php">visualizar</a></li>
            <li><a href="cadastrocli.php" class="active">cadastrar</a></li>
          </ul>
        </li>
        <li><a href="visu_fun.php" >funcionários</a>
          <ul>
            <li><a href="pesquisa_fun.php">visualizar</a></li>
            <li><a href="cadastrofunc.php" >cadastrar</a></li>
          </ul>
        </li>
        <li><a href="visu_horarios.php" >Horários</a>
          <ul>
            <li><a href="pesquisahorarios.php">visualizar</a></li>
            <li><a href="cadastrohorarios.php">cadastrar</a></li>
          </ul>
      </ul>
      <ul> 
      <div class="btn_sair">
  <p>Olá, <?php echo $_SESSION['usuario']; ?>!</p>
   <a href="logout.php">Sair</a>
</div>
    </div>
  </div>
  <form method="post">
    <div class="main-cadastro">
      <div class="Cadastro">
        <div class="card-cadastro">
          <h1> Cadastro:  </h1><br><br><br><br>
          
          
          <div class="textfield">
            <label for="funcionario">Funcionário:</label>
             <select id="cod_func_fk" name="cod_func_fk">
                <?php foreach ($dados as $d){
                    echo "<option value='{$d['cod_func']}'>{$d['nome_func']}</option>";

                }
                ?>
             </select>
           </div> 
           <div class="textfield">
            <label for="servicos">Serviço:</label>
             <select id="cod_serv_fk" name="cod_serv_fk">
                <?php foreach ($dadosS as $ds){
                    echo "<option value='{$ds['cod_serv']}'>{$ds['nome_serv']}</option>";

                }
                ?>
             </select>
           </div> 
           <div class="textfield">
            <label for="clientes">Cliente:</label>
             <select id="cod_cli_fk" name="cod_cli_fk">
                <?php foreach ($dadosC as $dc){
                    echo "<option value='{$dc['cod_cli']}'>{$dc['nome_cli']}</option>";

                }
                ?>
             </select>
           </div> 
           <div class="textfield">
            <label for="data_agend">Data de agendamento:</label>
            <input type="date" name="data_agend" id="data_agend">
          </div>
          <div class="textfield">
            <label for="hora_agend">Horario de agendamento:</label>
            <input type="time" name="hora_agend" id="hora_agend">
          </div>

         
    
    <button class="btn-1" name="btnsalvar">Cadastrar</button>
          <button class="btn-2" name="btncancelar">Cancelar</button>
        </div>
      </div>
    </div>
  </form>
  <?php if (!empty($message)) : ?>
        <div><?php echo $message; ?></div>
    <?php endif; ?>
 
</body>
</html>





