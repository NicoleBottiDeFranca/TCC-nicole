<?php
function brmy($data)
{
    $dataa = implode("/", array_reverse(explode("-", $data)));
    return $dataa;
}

function mybr($data)
{
    $datam = implode("-", array_reverse(explode("/", $data)));
    return $datam;
}
?>