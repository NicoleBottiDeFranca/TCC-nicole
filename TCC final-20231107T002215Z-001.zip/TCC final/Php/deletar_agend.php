<?php
if (!empty($_GET['id'])) {

    include_once ("conexao2.php");
   
    $id= $_GET['id'];
    $sqlSelect = "SELECT * FROM tb_agendamentos WHERE cod_agendamento=$id";
    $result = $conexao-> query($sqlSelect);
    
    if($result-> num_rows > 0)
    {
      $sqlDelete = "DELETE FROM tb_agendamentos WHERE cod_agendamento=$id";
      $resultDelete = $conexao->query($sqlDelete);
  }
 }   
      header('location:pesquisa_agend.php');
  

    
  
  ?>