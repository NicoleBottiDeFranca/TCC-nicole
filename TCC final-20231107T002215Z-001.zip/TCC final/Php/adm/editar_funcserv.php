<?php

session_start();


if (!isset($_SESSION['usuario'])) {
    
    header('Location: ../pagina_login.php');
    exit;
}
include_once("conexao2.php");

$sqlc = "SELECT * FROM tb_funcionarios";
$resultc = $conexao->query($sqlc);

$dados_funcionarios = array();
while ($row = mysqli_fetch_assoc($resultc)) {
    $dados_funcionarios[] = $row;
}

$sqls = "SELECT * FROM tb_servicos";
$results = $conexao->query($sqls);

$dados_servicos = array();
while ($row = mysqli_fetch_assoc($results)) {
    $dados_servicos[] = $row;
}

$cod_func_fk = $cod_serv_fk = ""; 

if (!empty($_GET['id'])) {

    include_once("conexao2.php");
   
    $id = $_GET['id'];
    $sqlSelect = "SELECT * FROM tb_funcionarios_servicos WHERE cod_func_fk=$id";
    $resultc = $conexao->query($sqlSelect);
    
    if ($resultc->num_rows > 0) {
        while ($user_data = mysqli_fetch_assoc($resultc)) {
            $cod_func_fk = $user_data['cod_func_fk'];
            $cod_serv_fk = $user_data['cod_serv_fk'];
        }
    } else {
        header('location:pesquisafuncserv.php');
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="../css/style_cadfuncserv.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../img/logo.png">
    <title>cadastro func/serv</title>
</head>
<body>
    <div class="header" id="header">
    <div class="logo_header">
      <img src="../img/logo.png" alt="sales_portas">
    </div>

    <div class="nagivation_header">
      <ul>
        <li><a href="visu_agend.php" >agendamentos</a>
          <ul>
            <li><a href="pesquisa_agend.php">visualizar</a></li>
            <li><a href="cad_agend.php">cadastrar</a></li>
          </ul>
        </li>
          <li><a href="visu_serv.php" class="active" >Serviços</a>
          <ul>
            <li><a href="pesquisaserv.php">visualizar</a></li>
            <li><a href="cadastroserv.php">cadastrar</a></li>
            <li><a href="cadastrofuncserv.php"  class="active">funcionário</a></li>
            <li><a href="pesquisafuncserv.php">visualizar FS</a></li>
          </ul>
          
        </li>
        <li><a href="visu_cli.php" >clientes</a>
          <ul>
            <li><a href="pesquisa_cli.php">visualizar</a></li>
            <li><a href="cadastrocli.php" class="active">cadastrar</a></li>
          </ul>
        </li>
        <li><a href="visu_fun.php" >funcionários</a>
          <ul>
            <li><a href="pesquisa_fun.php">visualizar</a></li>
            <li><a href="cadastrofunc.php" >cadastrar</a></li>
          </ul>
        </li>
        <li><a href="visu_horarios.php" >Horários</a>
          <ul>
            <li><a href="pesquisahorarios.php">visualizar</a></li>
            <li><a href="cadastrohorarios.php">cadastrar</a></li>
          </ul>
      </ul>
      <ul> 
      <div class="btn_sair">
  <p>Olá, <?php echo $_SESSION['usuario']; ?>!</p>
   <a href="logout.php">Sair</a>
</div>
    </div>
  </div>

    <form action="savefuncserv.php" method="post">
        <div class="main-cadastro">
            <div class="Cadastro">
                <div class="card-cadastro">
                    <h1> Alterar Serviço e funcionário</h1><br><br><br><br>
                    
                    <div class="textfield">
                        <label for="funcionario">Funcionário:</label>
                        <select id="cod_func_fk" name="cod_func_fk">
                            <?php foreach ($dados_funcionarios as $d) {
                                $selected = ($d['cod_func'] == $cod_func_fk) ? "selected" : "";
                                echo "<option value='{$d['cod_func']}' $selected>{$d['nome_func']}</option>";
                            } ?>
                        </select>
                    </div> 
                    <div class="textfield">
                        <label for="servicos">Serviço:</label>
                        <select id="cod_serv_fk" name="cod_serv_fk">
                            <?php foreach ($dados_servicos as $ds) {
                                $selected = ($ds['cod_serv'] == $cod_serv_fk) ? "selected" : "";
                                echo "<option value='{$ds['cod_serv']}' $selected>{$ds['nome_serv']}</option>";
                            } ?>
                        </select>
                    </div> 
                    <input type="hidden" name="cod_func_fk" value="<?php  echo $id?>">
                    <button class="btn-1" name="update">Alterar</button>
                    <button class="btn-2" name="btncancelar">Cancelar</button>
                </div>
            </div>
        </div>
    </form>
</body>
</html>
