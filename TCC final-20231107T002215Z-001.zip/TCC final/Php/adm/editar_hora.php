<?php

session_start();


if (!isset($_SESSION['usuario'])) {
    
    header('Location: ../pagina_login.php');
    exit;
}

include_once ("conexao2.php");

$sqlc = "SELECT * FROM tb_funcionarios";
$resultc = $conexao->query($sqlc);

$dados = array();
while ($row =  mysqli_fetch_assoc($resultc)) {
    $dados[] = $row;
}

  if (!empty($_GET['id'])) {

    include_once ("conexao2.php");
   
    $id= $_GET['id'];
    $sqlSelect = "SELECT * FROM tb_horarios WHERE cod_horario=$id";
    $result = $conexao-> query($sqlSelect);
    
    if($result-> num_rows > 0)
    {
      while($user_data = mysqli_fetch_assoc($result))
      {
    $dia_semana    = $user_data['dia_semana'];
    $entrada_manha = $user_data['entrada_manha'];
    $saida_manha  = $user_data['saida_manha'];
    $entrada_tarde  = $user_data['entrada_tarde'];
    $saida_tarde  = $user_data['saida_tarde'];
    $cod_func_fk  = $user_data['cod_func_fk'];
    

    }
    
  }
   else
    {
      header('location:pesquisahorarios.php');
    }

    
  }

    
?>
      

<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="../css/style_cadfuncserv.css">
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-sacle=1.0">
  <link rel="shortcut icon" href="../img/logo.png">
  <title>Alteração do horario</title>
</head>
<body>
  <div class="header" id="header">
    <div class="logo_header">
      <img src="../img/logo.png" alt="sales_portas">
    </div>

    <div class="nagivation_header">
      <ul>
        <li><a href="visu_agend.php" >agendamentos</a>
          <ul>
            <li><a href="pesquisa_agend.php">visualizar</a></li>
            <li><a href="cad_agend.php">cadastrar</a></li>
          </ul>
        </li>
          <li><a href="visu_serv.php" >Serviços</a>
          <ul>
            <li><a href="pesquisaserv.php">visualizar</a></li>
            <li><a href="cadastroserv.php">cadastrar</a></li>
            <li><a href="cadastrofuncserv.php">funcionário</a></li>
            <li><a href="pesquisafuncserv.php">visualizar FS</a></li>
          </ul>
          
        </li>
        <li><a href="visu_cli.php" >clientes</a>
          <ul>
            <li><a href="pesquisa_cli.php">visualizar</a></li>
            <li><a href="cadastrocli.php" class="active">cadastrar</a></li>
          </ul>
        </li>
        <li><a href="visu_fun.php">funcionários</a>
          <ul>
            <li><a href="pesquisa_fun.php">visualizar</a></li>
            <li><a href="cadastrofunc.php" >cadastrar</a></li>
          </ul>
        </li>
        <li><a href="visu_horarios.php" class="active">Horários</a>
          <ul>
            <li><a href="pesquisahorarios.php">visualizar</a></li>
            <li><a href="cadastrohorarios.php" class="active">cadastrar</a></li>
          </ul>
      </ul>
      <ul> 
      <div class="btn_sair">
  <p>Olá, <?php echo $_SESSION['usuario']; ?>!</p>
   <a href="logout.php">Sair</a>
</div>
    </div>
  </div>

  <form action="saveHora.php" method="post">
    <div class="main-cadastro">
      <div class="Cadastro">
        <div class="card-cadastro">
          <h1>Alterar Horários</h1><br><br><br><br>
          
          
          <div class="textfield">
    <label for="dia_semana">Dia da semana:</label>
    <select name="dia_semana" id="dia_semana">
        <option value="segunda-sexta" <?php if ($dia_semana == "segunda-sexta") echo "selected"; ?>>Segunda a Sexta</option>
        <option value="segunda-sabado" <?php if ($dia_semana == "segunda-sabado") echo "selected"; ?>>Segunda a Sábado</option>
    </select>
</div>
          <div class="textfield">
            <label for="entrada_manha">Entrada manhã:</label>
            <input type="time" name="entrada_manha" id="entrada_manha" value="<?php echo $entrada_manha ?>">
          </div>

          <div class="textfield">
            <label for="saida_manha">Saida manhã:</label>
            <input type="time" name="saida_manha" id="saida_manha" value="<?php echo $saida_manha ?>">
          </div>

          <div class="textfield">
            <label for="entrada_tarde">Entrada tarde:</label>
            <input type="time" name="entrada_tarde" id="entrada_tarde" value="<?php echo $entrada_tarde ?>">
          </div>

          <div class="textfield">
            <label for="saida_tarde">Saida tarde:</label>
            <input type="time" name="saida_tarde" id="saida_tarde" value="<?php echo $saida_tarde ?>">
          </div>
          <div class="textfield">
    <label for="funcionario">Funcionário:</label>
    <select name="cod_func_fk" id="cod_func_fk">
        <?php foreach ($dados as $d) {
            $selected = ($d['cod_func'] == $cod_func_fk) ? "selected" : "";
            echo "<option value='{$d['cod_func']}' $selected>{$d['nome_func']}</option>";
        } ?>
    </select>
</div>

                
           
          <input type="hidden" name="cod_horario" value="<?php  echo $id?>">
         <button class="btn-1" name="update">alterar</button>
          <button class="btn-2" name="btncancelar">Cancelar</button>
        </div>
      </div>
    </div>
  </form>
</body>
</html>