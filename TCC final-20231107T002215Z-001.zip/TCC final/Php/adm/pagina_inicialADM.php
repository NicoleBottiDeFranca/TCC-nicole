<?php

session_start();


if (!isset($_SESSION['usuario'])) {
    
    header('Location: ../pagina_login.php');
    exit;
}

?>
<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="../css/style_pginicial-adm.css">
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-sacle=1.0">
  <link rel="shortcut icon" href="../img/logo.png">
  <title>Página principal</title>
</head>
<body>
  <div class="header" id="header">
    <div class="logo_header">
      <img src="../img/logo.png" alt="sales_portas">
    </div>

    <div class="nagivation_header">
      <ul>
        <li><a href="visu_agend.php" >Agendamentos</a>
          <ul>
            <li><a href="pesquisa_agend.php">Visualizar</a></li>
            <li><a href="cad_agend.php">Cadastrar</a></li>
          </ul>
        </li>
        <li><a href="visu_serv.php"  >serviço</a>
          <ul>
            <li><a href="pesquisaserv.php">Visualizar S</a></li>
            <li><a href="cadastroserv.php">Cadastrar</a></li>
            <li><a href="cadastrofuncserv.php">Funcionário</a></li>
            <li><a href="pesquisafuncserv.php">Visualizar FS</a></li>
           </ul>
          </li>
        <li><a href="visu_cli.php" >Clientes</a>
          <ul>
            <li><a href="pesquisa_cli.php" >Visualizar</a></li>
            <li><a href="cadastrocli.php" >Cadastrar</a></li>
          </ul>
        </li>
        <li><a href="visu_fun.php">Funcionários</a>
          <ul>
            <li><a href="pesquisa_fun.php">Visualizar</a></li>
            <li><a href="cadastrofunc.php" >Cadastrar</a></li>
          </ul>
        </li>
        <li><a href="visu_horarios.php" >Horários</a>
          <ul>
            <li><a href="pesquisahorarios.php">Visualizar</a></li>
            <li><a href="cadastrohorarios.php">Cadastrar</a></li>
          </ul>
      </ul>
      <div class="btn_sair">
  <p>Olá, <?php echo $_SESSION['usuario']; ?>!</p>
   <a href="logout.php">Sair</a>
</div>
    </div>
  </div>
  <h1>Página do administrador!</h1>
  <div class="imagem">
    <img src="../img/img_adm.svg" class="img_c" alt=""><br>
  </div>
  
 
 
    
</body></html>