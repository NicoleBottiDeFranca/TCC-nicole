<?php
include_once("conexao2.php");
if (isset($_POST['update']))
{   $id = $_POST['cod_serv'];
    $nome = $_POST['nome_serv'];
    $tipo_serv = $_POST['tipo_serv'];
    $tempo_duracao  = $_POST['tempo_duracao'];
    $telefone  = $_POST['tel_func'];
    $email  = $_POST['email_func'];
    $data_contratacao  = $_POST['data_contat'];
    $tipo  = $_POST['tipo_cadastro'];
    $usuario  = $_POST['usuario'];
    $senha  =$_POST['senha'];

    $sqlUpdate = "UPDATE tb_servicos SET nome_serv='$nome', tipo_serv='$tipo_serv', tempo_duracao='$tempo_duracao' WHERE cod_serv='$id'";
    $result = $conexao-> query($sqlUpdate);
    
} 
header('location:pesquisaserv.php');
?>