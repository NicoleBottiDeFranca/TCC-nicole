<?php
session_start();


if (!isset($_SESSION['usuario'])) {
    
    header('Location: ../pagina_login.php');
    exit;
}
include_once "conexaosales.php";

function cadastrarFuncionario()
{
    $pdo = conectar();
    $message = '';

    if (isset($_POST['btnsalvar'])) {
        $nome = $_POST["nome_func"];
        $data_nasc = $_POST["data_nasc_func"];
        $cpf = $_POST["cpf_func"];
        $telefone = $_POST["tel_func"];
        $email = $_POST["email_func"];
        $data_contratacao = $_POST["data_contat"];
        $tipo = $_POST["tipo_cadastro"];
        $usuario = $_POST["usuario"];
        $senha = $_POST["senha"];

        try {
            $stmt = $pdo->prepare("INSERT INTO tb_funcionarios (nome_func, data_nasc_func, cpf_func, tel_func, email_func, data_contat, tipo_cadastro, usuario, senha) VALUES (:nome_func, :data_nasc_func, :cpf_func, :tel_func, :email_func, :data_contat, :tipo_cadastro, :usuario, :senha)");
            $stmt->bindParam(':nome_func', $nome);
            $stmt->bindParam(':data_nasc_func', $data_nasc);
            $stmt->bindParam(':cpf_func', $cpf);
            $stmt->bindParam(':tel_func', $telefone);
            $stmt->bindParam(':email_func', $email);
            $stmt->bindParam(':data_contat', $data_contratacao);
            $stmt->bindParam(':tipo_cadastro', $tipo);
            $stmt->bindParam(':usuario', $usuario);
            $stmt->bindParam(':senha', $senha);

            if ($stmt->execute()) {
                $message = 'Funcionário cadastrado com sucesso!';
                header("Location: sucesso_adm.php");
                exit; 
            } else {
                $message = 'Algum dos dados informados está inválido.';
            }
        } catch (Exception $e) {
            $message = 'Erro ao cadastrar: ' . $e->getMessage();
        }
    }

    return $message;
}

$message = cadastrarFuncionario();
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="../css/styleFuncad.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script type="text/javascript" src="../js/jquery.js"></script>
    <script type="text/javascript" src="../js/jquery.mask.js"></script>
    <script type="text/javascript" src="../js/mask.js"></script>
    <title>Cadastro funcionário ADM</title>
    <link rel="shortcut icon" href="../img/logo.png">
</head>
<body>
    <div class="header" id="header">
        <div class="logo_header">
            <img src="../img/logo.png" alt="sales_portas">
        </div>

        <div class="nagivation_header">
            <ul>
                <li><a href="visu_agend.php">agendamentos</a>
                    <ul>
                        <li><a href="pesquisa_agend.php">visualizar</a></li>
                        <li><a href="cad_agend.php">cadastrar</a></li>
                    </ul>
                </li>
                <li><a href="visu_serv.php" >Serviços</a>
                <ul>
                    <li><a href="pesquisaserv.php">visualizar</a></li>
                     <li><a href="cadastroserv.php">cadastrar</a></li>
                     <li><a href="cadastrofuncserv.php">funcionário</a></li>
                     <li><a href="pesquisafuncserv.php">visualizar FS</a></li>
                </ul>
          
                <li><a href="visu_cli.php">clientes</a>
                    <ul>
                        <li><a href="pesquisa_cli.php">visualizar</a></li>
                        <li><a href="cadastrocli.php">cadastrar</a></li>
                    </ul>
                </li>
                <li><a href="visu_fun.php" class="active">funcionários</a>
                    <ul>
                        <li><a href="pesquisa_fun.php">visualizar</a></li>
                        <li><a href="cadastrofunc.php" class="active">cadastrar</a></li>
                    </ul>
                </li>
                <li><a href="visu_horarios.php" >Horários</a>
          <ul>
            <li><a href="pesquisahorarios.php">visualizar</a></li>
            <li><a href="cadastrohorarios.php">cadastrar</a></li>
          </ul>
            </ul>
            <div class="btn_sair">
  <p>Olá, <?php echo $_SESSION['usuario']; ?>!</p>
   <a href="logout.php">Sair</a>
</div>
    </div>
  </div>
    <form method="POST" action="cadastrofunc.php">
        <div class="main-cadastro">
            <div class="cadastro">
                <div class="card-cadastro">
                    <h1>Cadastro Do Funcionário</h1><br><br><br><br>

                    <div class="textfield">
                        <label for="nome">Nome:</label>
                        <input type="text" name="nome_func" id="nome_func" size="40" placeholder="Nome completo" required>
                    </div>

                    <div class="textfield">
                        <label for="data_nasc">Data de Nascimento:</label>
                        <input type="date" name="data_nasc_func" id="data_nasc_func" required>
                    </div>

                    <div class="textfield">
                        <label for="cpf">CPF:</label>
                        <input type="text" class="cpf" name="cpf_func" id="cpf_func" size="14" placeholder="Somente números" required>
                    </div>
                    <div class="textfield">
                        <label for="tel">Telefone:</label>
                        <input type="text" class="sp_celphones" name="tel_func" id="tel_func" size="14" placeholder="Somente números" required>
                    </div>

                    <div class="textfield">
                        <label for="email">Email:</label>
                        <input type="email" name="email_func" id="email_func" size="40" placeholder="Email válido">
                    </div>

                    <div class="textfield">
                        <label for="data_contratacao">Data de Contratação:</label>
                        <input type="date" name="data_contat" id="data_contat" required>
                    </div>

                    <div class="textfield">
                        <label for="tipo">Tipo de cadastro:</label>
                        <input type="text" name="tipo_cadastro" id="tipo_cadastro" placeholder="Digite 'A' para administrador e 'F' para funcionário" required>
                    </div>

                    <br>
                    <h2>Login</h2>
                    <div class="textfield">
                        <label for="usuario">Usuário:</label>
                        <input type="text" name="usuario" id="usuario" autocomplete="off" placeholder="Cadastre um login para o funcionário" required>
                    </div>
                    <div class="textfield">
                        <label for="senha">Senha:</label>
                        <input type="password" name="senha" id="senha" autocomplete="" placeholder="Cadastre uma senha" required>
                    </div>

                    <button class="btn-1" type="submit" name="btnsalvar">Cadastrar</button>
                    <button class="btn-2">Cancelar</button>
                </div>
            </div>
        </div>
    </form>

    <?php if (!empty($message)) : ?>
        <div><?php echo $message; ?></div>
    <?php endif; ?>
</body>
</html>