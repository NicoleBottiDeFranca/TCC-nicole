<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    
  header('Location: ../pagina_login.php');
  exit;
}
include_once "conexaosales.php";

$pdo = conectar();
$sqlc = "SELECT * FROM tb_funcionarios";
$stmtc = $pdo->prepare($sqlc);
$stmtc->execute();
$dados = $stmtc->fetchAll(PDO::FETCH_ASSOC);
$sql = "SELECT * FROM tb_horarios ORDER BY cod_horario DESC";
$result = $pdo->query($sql);

?>

<!DOCTYPE html>
<html>
<head>
<head>
  

  <link rel="stylesheet" href="../css/style_pesquisaservADM.css">
  
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-sacle=1.0">
  <link rel="shortcut icon" href="../img/logo.png">
  <title>pesquisa horarios</title>
</head>
<body>
<div class="header" id="header">
    <div class="logo_header">
      <img src="../img/logo.png" alt="sales_portas">
    </div>

    <div class="nagivation_header">
      <ul>
        <li><a href="visu_agend.php" >agendamentos</a>
          <ul>
            <li><a href="pesquisa_agend.php">visualizar</a></li>
            <li><a href="cad_agend.php">cadastrar</a></li>
          </ul>
        </li>
      <li><a href="visu_serv.php" >Serviços</a>
          <ul>
            <li><a href="pesquisaserv.html"class="active">visualizar</a></li>
            <li><a href="cadastroserv.php">cadastrar</a></li>
            <li><a href="cadastrofuncserv.php">funcionário</a></li>
            <li><a href="pesquisafuncserv.php">visualizar FS</a></li>
          </ul>
          
        <li><a href="visu_cli.php"  >clientes</a>
          <ul>
            <li><a href="pesquisa_cli.php">visualizar</a></li>
            <li><a href="cadastrocli.php">cadastrar</a></li>
          </ul>
        </li>
        <li><a href="visu_fun.php" >funcionários</a>
          <ul>
            <li><a href="pesquisa_fun.php" >visualizar</a></li>
            <li><a href="cadastrofunc.php" >cadastrar</a></li>
          </ul>
        </li>
        <li><a href="visu_horarios.php" class="active" >Horários</a>
          <ul>
            <li><a href="pesquisahorarios.php">visualizar</a></li>
            <li><a href="cadastrohorarios.php">cadastrar</a></li>
          </ul>
      </ul>
      <div class="btn_sair">
  <p>Olá, <?php echo $_SESSION['usuario']; ?>!</p>
   <a href="logout.php">Sair</a>
</div>
    </div>
  </div>
  
  <div class="tabela">
    <br>
    <table>
      
        <tr>
          <th scope="col">Código</th>
          <th scope="col">Dia da semana</th>
          <th scope="col">Entrada manhã</th>
          <th scope="col">Saida manhã</th>
          <th scope="col">Entrada tarde</th>
          <th scope="col">Saida tarde</th>
          <th scope="col">Funcionário</th>
          <th scope="col">...</th>
          <th scope="col">...</th>
        </tr>
      
    
</div>
      <tbody>
        <?php 
        while ($user_data = $result->fetch(PDO::FETCH_ASSOC)) {
          echo "<tr>";
          echo "<td>".$user_data['cod_horario']."</td>";
          echo "<td>".$user_data['dia_semana']."</td>";
          echo "<td>".$user_data['entrada_manha']."</td>";
          echo "<td>".$user_data['saida_manha']."</td>";
          echo "<td>".$user_data['entrada_tarde']."</td>";
          echo "<td>".$user_data['saida_tarde']."</td>";
          $cod_func_fk = $user_data['cod_func_fk'];
          $nome_funcionario = '';
          foreach ($dados as $d) {
            if ($d['cod_func'] == $cod_func_fk) {
              $nome_funcionario = $d['nome_func'];
              break;
            }
          }
      
          echo "<td>".$nome_funcionario."</td>";
          echo "<td>
          <a class='btn_editar' href='editar_hora.php?id=$user_data[cod_horario]'>
          <img src='../img/lapis.png'> 
          </a>
          </td>
          <td>
          <a class='btn_excluir' href='deletar_hora.php?id=$user_data[cod_horario]'>
          <img src='../img/lixo.png'>
          </a>
          </div>
          </td>
          ";
          
          echo "</tr>";
        }
    
        ?>
      </tbody>
    </table>
  </div>
 
</body>
</html>