<?php
if (!empty($_GET['id'])) {

include_once ("conexao2.php");

$id= $_GET['id'];
$sqlSelect = "SELECT * FROM tb_funcionarios_servicos WHERE cod_func_fk=$id";
$result = $conexao-> query($sqlSelect);

if($result-> num_rows > 0)
{
  $sqlDelete = "DELETE FROM  tb_funcionarios_servicos WHERE cod_func_fk=$id";
  $resultDelete = $conexao->query($sqlDelete);
}
}   
  header('location:pesquisafuncserv.php');




?>