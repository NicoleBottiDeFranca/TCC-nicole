<?php
session_start();

if (!isset($_SESSION['usuario'])) {
    
  header('Location: ../pagina_login.php');
  exit;
}
include_once "conexaosales.php";

$pdo = conectar();

$sql = "SELECT * FROM tb_clientes ORDER BY cod_cli DESC";
$result = $pdo->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
<head>
  

  <link rel="stylesheet" href="../css/style_pesquisacli-ADM.css">
  
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-sacle=1.0">
  <link rel="shortcut icon" href="../img/logo.png">
  <title>pesquisa clientes</title>
</head>
<body>
<div class="header" id="header">
    <div class="logo_header">
      <img src="../img/logo.png" alt="sales_portas">
    </div>

    <div class="nagivation_header">
      <ul>
        <li><a href="visu_agend.php" >agendamentos</a>
          <ul>
            <li><a href="pesquisa_agend.php">visualizar</a></li>
            <li><a href="formagend.html">cadastrar</a></li>
          </ul>
        </li>
      <li><a href="visu_serv.php" >Serviços</a>
          <ul>
            <li><a href="pesquisaserv.php">visualizar</a></li>
            <li><a href="formaserv.php">cadastrar</a></li>
            <li><a href="cadastrofuncserv.php">funcionário</a></li>
            <li><a href="pesquisafuncserv.php">visualizar FS</a></li>
          </ul>
          
        <li><a href="visu_cli.php" class="active" >clientes</a>
          <ul>
            <li><a href="pesquisa_cli.php" class="active">visualizar</a></li>
            <li><a href="cadastrocli.php">cadastrar</a></li>
          </ul>
        </li>
        <li><a href="visu_fun.php" >funcionários</a>
          <ul>
            <li><a href="pesquisa_fun.php" >visualizar</a></li>
            <li><a href="cadastrofunc.php" >cadastrar</a></li>
          </ul>
        </li>
        <li><a href="visu_horarios.php" >Horários</a>
          <ul>
            <li><a href="pesquisahorarios.php">visualizar</a></li>
            <li><a href="cadastrohorarios.php">cadastrar</a></li>
          </ul>
      </ul>

      <div class="btn_sair">
  <p>Olá, <?php echo $_SESSION['usuario']; ?>!</p>
   <a href="logout.php">Sair</a>
</div>
    </div>
  </div>
 
  
  <div class="tabela">
    <br>
    <table>
      
        <tr>
          <th scope="col">Código</th>
          <th scope="col">Nome</th>
          <th scope="col">Nascimento</th>
          <th scope="col">CPF</th>
          <th scope="col">Email</th>
          <th scope="col">Bairro</th>
          <th scope="col">Rua</th>
          <th scope="col">Número</th>
          <th scope="col">Complemento</th>
          <th scope="col">Ativo</th>
          <th scope="col">Cidade</th>
          <th scope="col">Telefone</th>
          <th scope="col">CEP</th>
          <th scope="col">...</th>
          <th scope="col">...</th>
        </tr>
      
    
</div>
      <tbody>
        <?php
        while ($user_data = $result->fetch(PDO::FETCH_ASSOC)) {
          echo "<tr>";
          echo "<td>".$user_data['cod_cli']."</td>";
          echo "<td>".$user_data['nome_cli']."</td>";
          echo "<td>".$user_data['data_nasc_cli']."</td>";
          echo "<td>".$user_data['cpf_cli']."</td>";
          echo "<td>".$user_data['email_cli']."</td>";
          echo "<td>".$user_data['bairro_cli']."</td>";
          echo "<td>".$user_data['rua_cli']."</td>";
          echo "<td>".$user_data['num_cli']."</td>";
          echo "<td>".$user_data['complemento_cli']."</td>";
          echo "<td>".$user_data['ativo_cli']."</td>";
          echo "<td>".$user_data['cod_cid']."</td>";
          echo "<td>".$user_data['tel_cli']."</td>";
          echo "<td>".$user_data['cep_cli']."</td>";
          echo "<td>
          <a class='btn_editar' href='editar_cli.php?id=$user_data[cod_cli]'>
          <img src='../img/lapis.png'> 
          </a>
          </td>
          <td>
          <a class='btn_excluir' href='deletar_cli.php?id=$user_data[cod_cli]'>
          <img src='../img/lixo.png'>
          </a>
          </div>
          </td>
          ";
          
          echo "</tr>";
        }
        ?>
      </tbody>
    </table>
  </div>
  
</body>
</html>
