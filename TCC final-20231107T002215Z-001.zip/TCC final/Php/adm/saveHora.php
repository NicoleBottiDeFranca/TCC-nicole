<?php
include_once("conexao2.php");
if (isset($_POST['update']))
{   $id = $_POST['cod_horario'];
    $dia_semana = $_POST["dia_semana"];   
    $entrada_manha = $_POST["entrada_manha"];
    $saida_manha = $_POST["saida_manha"];
    $entrada_tarde = $_POST["entrada_tarde"];
    $data_contratacao  = $_POST['data_contat'];
    $saida_tarde = $_POST["saida_tarde"];
    $cod_func_fk = $_POST["cod_func_fk"];
   

    $sqlUpdate = "UPDATE tb_horarios SET dia_semana='$dia_semana', entrada_manha='$entrada_manha', saida_manha='$saida_manha',entrada_tarde='$entrada_tarde', saida_tarde='$saida_tarde', cod_func_fk='$cod_func_fk' WHERE cod_horario='$id'";
    $result = $conexao-> query($sqlUpdate);
    
} 
header('location:pesquisahorarios.php');
?>