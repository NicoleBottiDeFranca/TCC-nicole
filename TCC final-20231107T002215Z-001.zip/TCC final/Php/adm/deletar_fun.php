<?php
if (!empty($_GET['id'])) {

    include_once ("conexao2.php");
   
    $id= $_GET['id'];
    $sqlSelect = "SELECT * FROM tb_funcionarios WHERE cod_func=$id";
    $result = $conexao-> query($sqlSelect);
    
    if($result-> num_rows > 0)
    {
      $sqlDelete = "DELETE FROM tb_funcionarios WHERE cod_func=$id";
      $resultDelete = $conexao->query($sqlDelete);
  }
 }   
      header('location:pesquisa_fun.php');
  

    
  
  ?>
