<?php
include_once("conexao2.php");
if (isset($_POST['update']))
{   $id = $_POST['cod_func'];
    $nome = $_POST['nome_func'];
    $data_nasc = $_POST['data_nasc_func'];
    $cpf  = $_POST['cpf_func'];
    $telefone  = $_POST['tel_func'];
    $email  = $_POST['email_func'];
    $data_contratacao  = $_POST['data_contat'];
    $tipo  = $_POST['tipo_cadastro'];
    $usuario  = $_POST['usuario'];
    $senha  =$_POST['senha'];

    $sqlUpdate = "UPDATE tb_funcionarios SET nome_func='$nome', data_nasc_func='$data_nasc', cpf_func='$cpf',tel_func='$telefone', email_func='$email', data_contat='$data_contratacao', tipo_cadastro='$tipo', usuario='$usuario', senha='$senha' WHERE cod_func='$id'";
    $result = $conexao-> query($sqlUpdate);
    
} 
header('location:pesquisa_fun.php');
?>