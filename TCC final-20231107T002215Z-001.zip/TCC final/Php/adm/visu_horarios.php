<?php
session_start();


if (!isset($_SESSION['usuario'])) {
    
    header('Location: ../pagina_login.php');
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="../css/style_visuhorarios.css">
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-sacle=1.0">
  <link rel="shortcut icon" href="../img/logo.png">
  <title>pagina principal agendamentos</title>
</head>
<body>
  <div class="header" id="header">
    <div class="logo_header">
      <img src="../img/logo.png" alt="sales_portas">
    </div>

    <div class="nagivation_header">
      <ul>
        <li><a href="visu_agend.php"  >agendamentos</a>
          <ul>
            <li><a href="pesquisa_agend.php">visualizar</a></li>
            <li><a href="cad_agend.php">cadastrar</a></li>
          </ul>
          <li><a href="visu_serv.php" >Serviços</a>
          <ul>
            <li><a href="pesquisaserv.php">visualizar</a></li>
            <li><a href="cadastroserv.php">cadastrar</a></li>
            <li><a href="cadastrofuncserv.php">funcionário</a></li>
            <li><a href="pesquisafuncserv.php">visualizar FS</a></li>
            
          </ul>

          
        <li><a href="visu_cli.php" >clientes</a>
          <ul>
            <li><a href="pesquisa_cli.php" >visualizar</a></li>
            <li><a href="cadastrocli.php" >cadastrar</a></li>
          </ul>
        </li>
        <li><a href="visu_fun.php">funcionários</a>
          <ul>
            <li><a href="pesquisa_fun.php">visualizar</a></li>
            <li><a href="cadastrofunc.php" >cadastrar</a></li>
          </ul>
        </li>
        <li><a href="visu_horarios.php" class="active" >Horários</a>
          <ul>
            <li><a href="pesquisahorarios.php">visualizar</a></li>
            <li><a href="cadastrohorarios.php">cadastrar</a></li>
          </ul>
      </ul>
      <div class="btn_sair">
  <p>Olá, <?php echo $_SESSION['usuario']; ?>!</p>
   <a href="logout.php">Sair</a>
</div>
    </div>
  </div>
  <h1>Horários:</h1>
  <div class="imagem">
    <img src="../img/img_horarios.svg" class="img_c" alt=""><br>
  </div>
  <div class="imagema">
    <button class="button"> <a href="#">visualizar</a></button>
     <button class="button"> <a href="formagend.html">cadastrar</a></button>
   </div>
 
 
    
</body></html>