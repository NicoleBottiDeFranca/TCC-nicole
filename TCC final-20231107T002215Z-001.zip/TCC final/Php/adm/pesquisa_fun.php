<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    
  header('Location: ../pagina_login.php');
  exit;
}
include_once "conexaosales.php";

$pdo = conectar();

$sql = "SELECT * FROM tb_funcionarios ORDER BY cod_func DESC";
$result = $pdo->query($sql);
?>
<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="../css/style_pesquisafun.css">
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-sacle=1.0">
  <link rel="shortcut icon" href="../img/logo.png">
  <title>Pesquisa funcionário</title>
</head>
<body>
  <div class="header" id="header">
    <div class="logo_header">
      <img src="../img/logo.png" alt="sales_portas">
    </div>

    <div class="nagivation_header">
      <ul>
        <li><a href="visu_agend.php" >agendamentos</a>
          <ul>
            <li><a href="pesquisa_agend.php">visualizar</a></li>
            <li><a href="cad_agend.php">cadastrar</a></li>
          </ul>
        </li>
        <li><a href="visu_serv.php" >Serviços</a>
          <ul>
            <li><a href="pesquisaserv.php">visualizar</a></li>
            <li><a href="formaserv.php">cadastrar</a></li>
            <li><a href="cadastrofuncserv.php">funcionário</a></li>
            <li><a href="pesquisafuncserv.php">visualizar FS</a></li>
          </ul>
          
        <li><a href="visu_cli.php" >clientes</a>
          <ul>
            <li><a href="pesquisa_cli.php">visualizar</a></li>
            <li><a href="cadastrocli.php">cadastrar</a></li>
          </ul>
        </li>
        <li><a href="visu_fun.php" class="active">funcionários</a>
          <ul>
            <li><a href="pesquisa_fun.php" class="active">visualizar</a></li>
            <li><a href="cadastrofunc.php" >cadastrar</a></li>
          </ul>
        </li>
        <li><a href="visu_horarios.php" >Horários</a>
          <ul>
            <li><a href="pesquisahorarios.php">visualizar</a></li>
            <li><a href="cadastrohorarios.php">cadastrar</a></li>
          </ul>
      </ul>
      <div class="btn_sair">
  <p>Olá, <?php echo $_SESSION['usuario']; ?>!</p>
   <a href="logout.php">Sair</a>
</div>
    </div>
  </div>
  
  
<div class="tabela">
    <br>
    <table>
      
        <tr>
          <th scope="col">Código</th>
          <th scope="col">Nome</th>
          <th scope="col">Nascimento</th>
          <th scope="col">CPF</th>
          <th scope="col">Telefone</th>
          <th scope="col">Email</th>
          <th scope="col">Contratação</th>
          <th scope="col">Ativo</th>
          <th scope="col">Tipo</th>
          <th scope="col">Usuário</th>
          <th scope="col">Senha</th>
          <th scope="col">...</th>
          <th scope="col">...</th>
        </tr>
        <tbody>
        <?php
        while ($user_data = $result->fetch(PDO::FETCH_ASSOC)) {
          echo "<tr>";
          echo "<td>".$user_data['cod_func']."</td>";
          echo "<td>".$user_data['nome_func']."</td>";
          echo "<td>".$user_data['data_nasc_func']."</td>";
          echo "<td>".$user_data['cpf_func']."</td>";
          echo "<td>".$user_data['tel_func']."</td>";
          echo "<td>".$user_data['email_func']."</td>";
          echo "<td>".$user_data['data_contat']."</td>";
          echo "<td>".$user_data['ativo_func']."</td>";
          echo "<td>".$user_data['tipo_cadastro']."</td>";
          echo "<td>".$user_data['usuario']."</td>";
          echo "<td>".md5($user_data['senha'])."</td>";

          echo "<td>
          <a class='btn_editar' href='editar_fun.php?id=$user_data[cod_func]'>
          <img src='../img/lapis.png'> 
          </a>
          </td>
          <td>
          <a class='btn_excluir' href='deletar_fun.php?id=$user_data[cod_func]'>
          <img src='../img/lixo.png'>
          </a>
          </div>
          </td>
          ";
          echo "</tr>";
        }
        ?>
      </tbody>
        
    </table>
      
    
</div>
</body>