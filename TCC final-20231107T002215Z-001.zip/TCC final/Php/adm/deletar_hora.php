<?php
if (!empty($_GET['id'])) {

    include_once ("conexao2.php");
   
    $id= $_GET['id'];
    $sqlSelect = "SELECT * FROM tb_horarios WHERE cod_horario=$id";
    $result = $conexao-> query($sqlSelect);
    
    if($result-> num_rows > 0)
    {
      $sqlDelete = "DELETE FROM tb_horarios WHERE cod_horario=$id";
      $resultDelete = $conexao->query($sqlDelete);
  }
 }   
      header('location:pesquisahorarios.php');
  

    
  
  ?>
