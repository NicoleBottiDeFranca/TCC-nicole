<?php
session_start();


if (!isset($_SESSION['usuario'])) {
    
    header('Location: ../pagina_login.php');
    exit;
}

  if (!empty($_GET['id'])) {

    include_once ("conexao2.php");
   
    $id= $_GET['id'];
    $sqlSelect = "SELECT * FROM tb_servicos WHERE cod_serv=$id";
    $result = $conexao-> query($sqlSelect);
    
    if($result-> num_rows > 0)
    {
      while($user_data = mysqli_fetch_assoc($result))
      {
    $nome   = $user_data['nome_serv'];
    $tipo_serv = $user_data['tipo_serv'];
    $tempo_duracao  = $user_data['tempo_duracao'];
    

    }
    
  }
   else
    {
      header('location:pesquisaserv.php');
    }

    
  }

    
?>
      

      <!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="../css/style_cadfuncserv.css">
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-sacle=1.0">
  <title>Alteração do  Serviço</title>
</head>
<body>
  <div class="header" id="header">
    <div class="logo_header">
      <img src="../img/logo.png" alt="sales_portas">
    </div>

    <div class="nagivation_header">
      <ul>
        <li><a href="visu_agend.php" >agendamentos</a>
          <ul>
            <li><a href="pesquisa_agend.php">visualizar</a></li>
            <li><a href="cad_agend.php">cadastrar</a></li>
          </ul>
          <li><a href="visu_serv.php" class="active" >Serviços</a>
          <ul>
            <li><a href="pesquisaserv.php">visualizar</a></li>
            <li><a href="cadastroserv.php"class="active">cadastrar</a></li>
            <li><a href="cadastrofuncserv.php">funcionário</a></li>
            <li><a href="pesquisafuncserv.php">visualizar FS</a></li>
          </ul>
          
        </li>
        <li><a href="visu_cli.html" >clientes</a>
          <ul>
            <li><a href="pesquisa_cli.php">visualizar</a></li>
            <li><a href="cadastrocli.php" >cadastrar</a></li>
          </ul>
        </li>
        <li><a href="visu_fun.php">funcionários</a>
          <ul>
            <li><a href="pesquisa_fun.html">visualizar</a></li>
            <li><a href="cadastrofunc.php" >cadastrar</a></li>
          </ul>
        </li>
      
      <li><a href="visu_horarios.php" >Horários</a>
          <ul>
            <li><a href="pesquisahorarios.php">visualizar</a></li>
            <li><a href="cadastrohorarios.php">cadastrar</a></li>
          </ul>
        </ul>
      <ul> 
      <div class="btn_sair">
  <p>Olá, <?php echo $_SESSION['usuario']; ?>!</p>
   <a href="logout.php">Sair</a>
</div>
    </div>
  </div>
     

  <form action="saveEditserv.php" method="post">
    <div class="main-cadastro">
      <div class="Cadastro">
        <div class="card-cadastro">
          <h1>Alterar Serviço</h1><br><br><br><br>
          
          <div class="textfield">
            <label for="nome">Nome:</label>
            <input type="text" name="nome_serv" id="nome_serv" size="40" placeholder="nome do serviço" value="<?php echo $nome ?>">
          </div>

          <div class="textfield">
            <label for="tipo">Tipo de serviço:</label>
            <input type="text" name="tipo_serv" id="tipo_serv" value="<?php echo $tipo_serv ?>">
          </div>

          <div class="textfield">
            <label for="tempo">Tempo de Duração:</label>
            <input type="time" name="tempo_duracao" id="tempo_duracao" value="<?php echo $tempo_duracao ?>">
          </div>
        
        <input type="hidden" name="cod_serv" value="<?php  echo $id?>">
        
    
    <button class="btn-1" name="update">Alterar</button>
          <button class="btn-2" name="btncancelar">Cancelar</button>
        </div>
      </div>
    </div>    
  </form>
  

</body>
</html>
