<?php

session_start();


if (!isset($_SESSION['usuario'])) {
    
    header('Location: ../pagina_login.php');
    exit;
}
include_once "conexaosales.php";

function cadastrarServico()
{
    $pdo = conectar();
    $message = '';

    if (isset($_POST['btnsalvar'])) {
        $nome = $_POST["nome_serv"];
        $tipo_serv = $_POST["tipo_serv"];
        $tempo_duracao = $_POST["tempo_duracao"];
        

        try {
            $stmt = $pdo->prepare("INSERT INTO tb_servicos (nome_serv, tipo_serv, tempo_duracao) VALUES (:nome_serv, :tipo_serv, :tempo_duracao)");
            $stmt->bindParam(':nome_serv', $nome);
            $stmt->bindParam(':tipo_serv', $tipo_serv);
            $stmt->bindParam(':tempo_duracao', $tempo_duracao);
           

            if ($stmt->execute()) {
                $message = 'serviço cadastrado com sucesso!';
                header("Location: sucesso_adm.php");
                exit; 
            } else {
                $message = 'Algum dos dados informados está inválido.';
            }
        } catch (Exception $e) {
            $message = 'Erro ao cadastrar: ' . $e->getMessage();
        }
    }

    return $message;
}

$message = cadastrarServico();
?>

<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="../css/style_cadfuncserv.css">
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-sacle=1.0">
  <link rel="shortcut icon" href="../img/logo.png">
  <title>cadastro Serviço</title>
</head>
<body>
  <div class="header" id="header">
    <div class="logo_header">
      <img src="../img/logo.png" alt="sales_portas">
    </div>

    <div class="nagivation_header">
      <ul>
        <li><a href="visu_agend.php" >agendamentos</a>
          <ul>
            <li><a href="pesquisa_agend.php">visualizar</a></li>
            <li><a href="cad_agend.php">cadastrar</a></li>
          </ul>
          <li><a href="visu_serv.php" class="active" >Serviços</a>
          <ul>
            <li><a href="pesquisaserv.php">visualizar</a></li>
            <li><a href="cadastroserv.php"class="active">cadastrar</a></li>
            <li><a href="cadastrofuncserv.php">funcionário</a></li>
            <li><a href="pesquisafuncserv.php">visualizar FS</a></li>
          </ul>
          
        </li>
        <li><a href="visu_cli.php" >clientes</a>
          <ul>
            <li><a href="pesquisa_cli.php">visualizar</a></li>
            <li><a href="cadastrocli.php" >cadastrar</a></li>
          </ul>
        </li>
        <li><a href="visu_fun.php">funcionários</a>
          <ul>
            <li><a href="pesquisa_fun.php">visualizar</a></li>
            <li><a href="cadastrofunc.php" >cadastrar</a></li>
          </ul>
        </li>
        <li><a href="visu_horarios.php" >Horários</a>
          <ul>
            <li><a href="pesquisahorarios.php">visualizar</a></li>
            <li><a href="cadastrohorarios.php">cadastrar</a></li>
          </ul>
      </ul>
      <ul> 
      <div class="btn_sair">
  <p>Olá, <?php echo $_SESSION['usuario']; ?>!</p>
   <a href="logout.php">Sair</a>
</div>
    </div>
  </div>
  <form method="post">
    <div class="main-cadastro">
      <div class="Cadastro">
        <div class="card-cadastro">
          <h1>Cadastro Do Serviço</h1><br><br><br><br>
          
          <div class="textfield">
            <label for="nome">Nome:</label>
            <input type="text" name="nome_serv" id="nome_serv" size="40" placeholder="nome do serviço">
          </div>

          <div class="textfield">
            <label for="tipo">Tipo de serviço:</label>
            <input type="text" name="tipo_serv" id="tipo_serv">
          </div>

          <div class="textfield">
            <label for="tempo">Tempo de Duração:</label>
            <input type="time" name="tempo_duracao" id="tempo_duracao" >
          </div>
          
        
    
    <button class="btn-1" name="btnsalvar">Cadastrar</button>
          <button class="btn-2" name="btncancelar">Cancelar</button>
        </div>
      </div>
    </div>
    <?php if (!empty($message)) : ?>
        <div><?php echo $message; ?></div>
    <?php endif; ?>
</body>
</html>