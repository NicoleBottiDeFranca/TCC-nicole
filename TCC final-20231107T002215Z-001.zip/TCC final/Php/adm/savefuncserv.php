<?php
include_once("conexao2.php");
if (isset($_POST['update']))
{   $id = $_POST['cod_func_fk'];
    $cod_func_fk = $_POST["cod_func_fk"];   
    $cod_serv_fk = $_POST["cod_serv_fk"];
    

    $sqlUpdate = "UPDATE tb_funcionarios_servicos SET cod_func_fk='$cod_func_fk', cod_serv_fk='$cod_serv_fk' WHERE cod_func_fk ='$id'";
    $result = $conexao-> query($sqlUpdate);
    
} 
header('location:pesquisafuncserv.php');
?>