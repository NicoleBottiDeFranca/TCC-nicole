<?php
session_start();

if (!isset($_SESSION['usuario'])) {
    header('Location: ../pagina_login.php');
    exit;
}

include_once "conexao.php";
$pdo = conectar();
$sqlc = "SELECT * FROM tb_funcionarios";
$stmtc = $pdo->prepare($sqlc);
$stmtc->execute();
$dados = $stmtc->fetchAll(PDO::FETCH_ASSOC);

function cadastrarHorario()
{
    $pdo = conectar();
    $message = '';

    if (isset($_POST['btnsalvar'])) {
        $dia_semana = $_POST["dia_semana"];
        $entrada_manha = $_POST["entrada_manha"];
        $saida_manha = $_POST["saida_manha"];
        $entrada_tarde = $_POST["entrada_tarde"];
        $saida_tarde = $_POST["saida_tarde"];
        $cod_func_fk = $_POST["cod_func_fk"];

        // Validar se os horários estão corretos
        if (strtotime($saida_manha) <= strtotime($entrada_manha) || strtotime($entrada_tarde) <= strtotime($saida_manha)) {
            $message = 'Os horários de saída não podem ser menores ou iguais aos horários de entrada.';
        } else {
            try {
                $stmt = $pdo->prepare("INSERT INTO tb_horarios (dia_semana, entrada_manha, saida_manha, entrada_tarde, saida_tarde, cod_func_fk) VALUES (:dia_semana, :entrada_manha, :saida_manha, :entrada_tarde, :saida_tarde, :cod_func_fk)");
                $stmt->bindParam(':dia_semana', $dia_semana);
                $stmt->bindParam(':entrada_manha', $entrada_manha);
                $stmt->bindParam(':saida_manha', $saida_manha);
                $stmt->bindParam(':entrada_tarde', $entrada_tarde);
                $stmt->bindParam(':saida_tarde', $saida_tarde);
                $stmt->bindParam(':cod_func_fk', $cod_func_fk);

                if ($stmt->execute()) {
                    $message = 'Cadastro realizado com sucesso!';
                    header("Location: sucesso_adm.php");
                    exit;
                } else {
                    $message = 'Algum dos dados informados está inválido.';
                }
            } catch (Exception $e) {
                $message = 'Erro ao cadastrar: ' . $e->getMessage();
            }
        }
    }

    return $message;
}

$message = cadastrarHorario();
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="../css/style_cadfuncserv.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-sacle=1.0">
    <link rel="shortcut icon" href="../img/logo.png">
    <title>Cadastro de Horários</title>
</head>
<body>
<div class="header" id="header">
    <div class="logo_header">
        <img src="../img/logo.png" alt="sales_portas">
    </div>

    <div class="nagivation_header">
        
        <ul>
            <li><a href="visu_agend.php" >Agendamentos</a>
                <ul>
                    <li><a href="pesquisa_agend.php">Visualizar</a></li>
                    <li><a href="cad_agend.php">Cadastrar</a></li>
                </ul>
            </li>
            <li><a href="visu_serv.php" >Serviços</a>
                <ul>
                    <li><a href="pesquisaserv.php">Visualizar</a></li>
                    <li><a href="cadastroserv.php">Cadastrar</a></li>
                    <li><a href="cadastrofuncserv.php">Funcionário</a></li>
                    <li><a href="pesquisafuncserv.php">Visualizar FS</a></li>
                </ul>
            </li>
            <li><a href="visu_cli.php" >Clientes</a>
                <ul>
                    <li><a href="pesquisa_cli.php">Visualizar</a></li>
                    <li><a href="cadastrocli.php" class="active">Cadastrar</a></li>
                </ul>
            </li>
            <li><a href="visu_fun.php">Funcionários</a>
                <ul>
                    <li><a href="pesquisa_fun.php">Visualizar</a></li>
                    <li><a href="cadastrofunc.php" >Cadastrar</a></li>
                </ul>
            </li>
            <li><a href="visu_horarios.php" class="active">Horários</a>
                <ul>
                    <li><a href="pesquisahorarios.php">Visualizar</a></li>
                    <li><a href="cadastrohorarios.php" class="active">Cadastrar</a></li>
                </ul>
            </li>
          </ul>
        <ul>
            <div class="btn_sair">
                <p>Olá, <?php echo $_SESSION['usuario']; ?>!</p>
                <a href="logout.php">Sair</a>
            </div>
        </ul>
    </div>
</div>

<form method="post">
    <div class="main-cadastro">
        <div class="Cadastro">
            <div class="card-cadastro">
                <h1>Cadastro De Horários</h1><br><br><br><br>

                <div class="textfield">
                  <label for="dia_semana">Dia da semana:</label>
               <select name="dia_semana" id="dia_semana">
               <option value="segunda-sexta">Segunda-Sexta</option>
              <option value="segunda-sabado">Segunda-Sábado</option>
              </select>
               </div>

                <div class="textfield">
                    <label for="entrada_manha">Entrada manhã:</label>
                    <input type="time" name="entrada_manha" id="entrada_manha">
                </div>

                <div class="textfield">
                    <label for="saida_manha">Saida manhã:</label>
                    <input type="time" name="saida_manha" id="saida_manha">
                </div>

                <div class="textfield">
                    <label for="entrada_tarde">Entrada tarde:</label>
                    <input type="time" name="entrada_tarde" id="entrada_tarde">
                </div>

                <div class="textfield">
                    <label for="saida_tarde">Saida tarde:</label>
                    <input type="time" name="saida_tarde" id="saida_tarde">
                </div>
                <div class="textfield">
                    <label for="funcionario">Funcionário:</label>
                    <select id="cod_func_fk" name="cod_func_fk">
                        <?php foreach ($dados as $d){
                            echo "<option value='{$d['cod_func']}'>{$d['nome_func']}</option>";
                        }
                        ?>
                    </select>
                </div>
                <div id="erro" style="color: red;"><?php echo $message; ?></div>

                <button class="btn-1" name="btnsalvar">Cadastrar</button>
                <button class="btn-2" name="btncancelar">Cancelar</button>
            </div>
        </div>
    </div>
</form>

<script>
    document.getElementById("entrada_manha").addEventListener("change", validarHorarios);
    document.getElementById("saida_manha").addEventListener("change", validarHorarios);
    document.getElementById("entrada_tarde").addEventListener("change", validarHorarios);
    document.getElementById("saida_tarde").addEventListener("change", validarHorarios);

    function validarHorarios() {
        var entradaManha = document.getElementById("entrada_manha").value;
        var saidaManha = document.getElementById("saida_manha").value;
        var entradaTarde = document.getElementById("entrada_tarde").value;
        var saidaTarde = document.getElementById("saida_tarde").value;

       
        var entradaManhaObj = new Date("1970-01-01T" + entradaManha);
        var saidaManhaObj = new Date("1970-01-01T" + saidaManha);
        var entradaTardeObj = new Date("1970-01-01T" + entradaTarde);
        var saidaTardeObj = new Date("1970-01-01T" + saidaTarde);

       
        if (entradaTardeObj <= saidaManhaObj) {
            document.getElementById("erro").innerHTML = "A entrada da tarde não pode ser menor ou igual à saída da manhã.";
        } else {
            document.getElementById("erro").innerHTML = "";
        }
    }
</script>
</body>
</html>
