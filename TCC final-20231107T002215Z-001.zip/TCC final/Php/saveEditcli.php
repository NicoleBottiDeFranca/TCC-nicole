<?php
include_once("conexao2.php");
if (isset($_POST['update']))
{   $id = $_POST['cod_cli'];
    $nome   = $_POST['nome_cli'];
    $data_nasc  =$_POST['data_nasc_cli'];
    $cpf  = $_POST['cpf_cli'];
    $email  = $_POST['email_cli'];
    $bairro  = $_POST['bairro_cli'];
    $rua  = $_POST['rua_cli'];
    $numero  = $_POST['num_cli'];
    $complemento  = $_POST['complemento_cli'];
    $cidade  = $_POST['cod_cid'];
    $telefone  = $_POST['tel_cli'];
    $cep  = $_POST['cep_cli'];

    $sqlUpdate = "UPDATE tb_clientes SET nome_cli='$nome', data_nasc_cli='$data_nasc', cpf_cli='$cpf', email_cli='$email', bairro_cli='$bairro', rua_cli='$rua', num_cli='$numero', complemento_cli='$complemento', cod_cid='$cidade', tel_cli='$telefone', cep_cli='$cep' WHERE cod_cli='$id'";
    $result = $conexao-> query($sqlUpdate);
    
} 
header('location:pesquisa_cli.php');
?>