<?php
include_once("conexao2.php");
if (isset($_POST['update']))
{   $id = $_POST['cod_agendamento'];
    $cod_func_fk = $_POST["cod_func_fk"];   
    $cod_serv_fk = $_POST["cod_serv_fk"];
    $cod_cli_fk = $_POST["cod_cli_fk"];
    $data_agend = $_POST["data_agend"];
    $hora_agend = $_POST["hora_agend"];
    

    $sqlUpdate = "UPDATE tb_agendamentos SET cod_func_fk='$cod_func_fk', cod_serv_fk='$cod_serv_fk', cod_cli_fk='$cod_cli_fk', data_agend='$data_agend', hora_agend='$hora_agend' WHERE cod_agendamento='$id'";
    $result = $conexao-> query($sqlUpdate);
    
} 
header('location:pesquisa_agend.php');
?>