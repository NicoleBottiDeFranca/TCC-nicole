<?php
include_once 'conexaosales.php';
$pdo = conectar();
session_start();

if(isset($_POST['submit'])){
   $usuario = $_POST['usuario'];
   $senha = ($_POST['senha']);

   $sql = "SELECT * FROM tb_funcionarios WHERE usuario = :usuario AND senha = :senha";

   $stmt = $pdo->prepare($sql);
   $stmt->bindParam(':usuario', $usuario);
   $stmt->bindParam(':senha', $senha);
   $stmt->execute();

   $res = $stmt->fetch(PDO::FETCH_ASSOC);
   $tipo_cadastro = $res['tipo_cadastro'];

   if($stmt->rowCount() > 0) {
    if($tipo_cadastro == "A") {
        $_SESSION['usuario'] = $usuario; // Defina o nome de usuário como variável de sessão
        header ('Location: adm/pagina_inicialADM.php');
    }
    else {
        $_SESSION['usuario'] = $usuario; // Defina o nome de usuário como variável de sessão
        header ('Location: pagina_inicialFUNC.php');
    }
   } else {
       // Trate o caso em que a autenticação falha, por exemplo, exibindo uma mensagem de erro.
       echo "Login falhou. Verifique suas credenciais.";
   }
}   
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-sacle=1.0">
  <link rel="shortcut icon" href="img/logo.png">
   <link rel="stylesheet" href="css/stylelogin.css">
    <body>
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
      <div class='main-login'>
        <div class="left-login"> 
          <h1>Seja bem vindo, funcionário!</h1>
         <img src="img/imagemaaa.svg"  class= "left-login-image" alt="imagem">
        </div>
        <div class="right-login">  
        <div class="card-login">
            <h1>Login</h1>
           <div class="textfield">
            <label for="usuario">Usuário</label>
            <input type="text" name="usuario" placeholder="usuário">
           </div>
           <div class="textfield">
            <label for="senha">Senha</label>
            <input type="password" name="senha" placeholder="senha">
           </div>
           <input type="submit" class="btn-login" name="submit" value="enviar">
          </div>
        </div>
      </div>
    </form>
    </body>
    </html>
