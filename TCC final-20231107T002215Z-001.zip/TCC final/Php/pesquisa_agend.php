<?php
session_start();

if (!isset($_SESSION['usuario'])) {
    header('Location: pagina_login.php');
    exit;
}

include_once "conexao.php";
$pdo = conectar();

$usuario = $_SESSION['usuario']; 

$sql_funcionario = "SELECT cod_func FROM tb_funcionarios WHERE usuario = :usuario";
$stmt_funcionario = $pdo->prepare($sql_funcionario);
$stmt_funcionario->bindParam(':usuario', $usuario, PDO::PARAM_STR);
$stmt_funcionario->execute();
$funcionario_id = $stmt_funcionario->fetchColumn();

$sql_agendamentos = "SELECT * FROM tb_agendamentos WHERE cod_func_fk = :funcionario_id ORDER BY cod_agendamento DESC";
$stmt_agendamentos = $pdo->prepare($sql_agendamentos);
$stmt_agendamentos->bindParam(':funcionario_id', $funcionario_id, PDO::PARAM_INT);
$stmt_agendamentos->execute();
$result = $stmt_agendamentos->fetchAll(PDO::FETCH_ASSOC);

$sqlf = "SELECT * FROM tb_funcionarios ";
$stmtf = $pdo->prepare($sqlf);
$stmtf->execute();
$dados = $stmtf->fetchAll(PDO::FETCH_ASSOC);

$sqls = "SELECT * FROM tb_servicos";
$stmts = $pdo->prepare($sqls);
$stmts->execute();
$dadosS = $stmts->fetchAll(PDO::FETCH_ASSOC);

$sqlc = "SELECT * FROM tb_clientes";
$stmtc = $pdo->prepare($sqlc);
$stmtc->execute();
$dadosC = $stmtc->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="css/style_pesquisagend_func.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-sacle=1.0">
    <link rel="shortcut icon" href="img/logo.png">
    <title>pesquisa servicos/funcionários</title>
</head>
<body>
<div class="header" id="header">
<div class="logo_header">
      <img src="img/logo.png" alt="sales_portas">
    </div>

    <div class="nagivation_header">
      <ul>
        <li><a href="visu_agend.php" class="active" >agendamentos</a>
          <ul>
            <li><a href="pesquisa_agend.php" class="active">visualizar</a></li>
            <li><a href="cad_agend.php">cadastrar</a></li>
          </ul>
        </li>
      <li><a href="visu_serv.php" >Serviços</a>
          <ul>
            <li><a href="pesquisaserv.html" >visualizar</a></li>
            
          </ul>
          
        <li><a href="visu_cli.php">clientes</a>
          <ul>
            <li><a href="pesquisa_cli.php">visualizar</a></li>
            <li><a href="cadastrocli.php">cadastrar</a></li>
          </ul>
        </li>
        
       
      </ul>
      <div class="btn_sair">
  <p>Olá, <?php echo $_SESSION['usuario']; ?>!</p>
   <a href="logout.php">Sair</a>
</div>
    </div>
  </div>
  
</div>

<div class="tabela">
    <br>
    <table>
        <tr>
            <th scope="col">Funcionário</th>
            <th scope="col">Serviço</th>
            <th scope="col">Clientes</th>
            <th scope="col">Data</th>
            <th scope="col">Horario</th>
            <th scope="col">...</th>
            <th scope="col">...</th>
        </tr>
        <tbody>
        <?php 
        foreach ($result as $user_data) {
            echo "<tr>";
            
            $cod_func_fk = $user_data['cod_func_fk'];
            $nome_funcionario = '';
            foreach ($dados as $d) {
                if ($d['cod_func'] == $cod_func_fk) {
                    $nome_funcionario = $d['nome_func'];
                    break;
                }
            }
            echo "<td>".$nome_funcionario."</td>";

            $cod_serv_fk = $user_data['cod_serv_fk'];
            $nome_servico = '';
            foreach ($dadosS as $ds) {
                if ($ds['cod_serv'] == $cod_serv_fk) {
                    $nome_servico = $ds['nome_serv'];
                    break;
                }
            }
            echo "<td>".$nome_servico."</td>";

            $cod_cli_fk = $user_data['cod_cli_fk'];
            $nome_cli = '';
            foreach ($dadosC as $dc) {
                if ($dc['cod_cli'] == $cod_cli_fk) {
                    $nome_cli = $dc['nome_cli'];
                    break;
                }
            }
            echo "<td>".$nome_cli."</td>";
            echo "<td>".$user_data['data_agend']."</td>";
            echo "<td>".$user_data['hora_agend']."</td>";
            echo "<td>
                <a class='btn_editar' href='editar_agend.php?id=$user_data[cod_agendamento]'>
                <img src='img/lapis.png'> 
                </a>
                </td>
                <td>
                <a class='btn_excluir' href='deletar_agend.php?id=$user_data[cod_agendamento]'>
                <img src='img/lixo.png'>
                </a>
                </div>
                </td>
            ";
            
            echo "</tr>";
        }
    
        ?>
        </tbody>
    </table>
</div>
 
</body>
</html>
