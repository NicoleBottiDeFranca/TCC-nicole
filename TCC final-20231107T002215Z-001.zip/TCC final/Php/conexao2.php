<?php
$dbHost = 'localhost';
$dbUsername = 'root';
$dbPassword = '';
$dbName = 'sales_portas';

$conexao = new mysqli($dbHost,$dbUsername,$dbPassword,$dbName);
?>
